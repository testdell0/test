using DASheetManager.Services.DTOs;
using DASheetManager.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DASheetManager.API.Controllers;

[Route("api/users")]
[Authorize]
public class UserController : ApiControllerBase
{
    private readonly IAuthService _authService;

    public UserController(IAuthService authService)
    {
        _authService = authService;
    }

    // -----------------------------------------------------------------------
    // GET /api/users
    // -----------------------------------------------------------------------
    /// <summary>List all users. Admin only.</summary>
    [HttpGet]
    public async Task<IActionResult> GetAllUsers()
    {
        if (!IsAdmin())
            return Forbid();

        var users = await _authService.GetAllUsersAsync();
        return Ok(users);
    }

    // -----------------------------------------------------------------------
    // POST /api/users
    // -----------------------------------------------------------------------
    /// <summary>Create a single user account. Admin only.</summary>
    [HttpPost]
    public async Task<IActionResult> CreateUser([FromBody] CreateUserRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        var (user, error) = await _authService.CreateUserAsync(request);
        if (user is null)
            return BadRequest(new { message = error });

        return CreatedAtAction(nameof(GetAllUsers), new { }, user);
    }

    // -----------------------------------------------------------------------
    // POST /api/users/bulk
    // -----------------------------------------------------------------------
    /// <summary>
    /// Bulk-create users. Admin only.
    /// Each user in the list is processed independently — errors are reported
    /// per-row and never abort the rest of the batch.
    /// </summary>
    [HttpPost("bulk")]
    public async Task<IActionResult> BulkCreateUsers([FromBody] BulkCreateUserRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        if (request.Users is null || request.Users.Count == 0)
            return BadRequest(new { message = "The user list must not be empty." });

        var result = await _authService.BulkCreateUsersAsync(request);
        return Ok(result);
    }

    // -----------------------------------------------------------------------
    // POST /api/users/bulk-delete
    // -----------------------------------------------------------------------
    /// <summary>
    /// Bulk-delete users. Admin only.
    /// The authenticated user cannot delete their own account.
    /// Errors are collected per-row; the endpoint always returns 200 with a summary.
    /// </summary>
    [HttpPost("bulk-delete")]
    public async Task<IActionResult> BulkDeleteUsers([FromBody] BulkDeleteRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        if (request.UserIds is null || request.UserIds.Count == 0)
            return BadRequest(new { message = "The user ID list must not be empty." });

        var currentUserId = GetCurrentUserId();
        if (currentUserId is null)
            return Unauthorized();

        var result = await _authService.BulkDeleteUsersAsync(request, currentUserId.Value);
        return Ok(result);
    }

    // -----------------------------------------------------------------------
    // POST /api/users/{id}/toggle-active
    // -----------------------------------------------------------------------
    /// <summary>Enable or disable a user account. Admin only.</summary>
    [HttpPost("{id:int}/toggle-active")]
    public async Task<IActionResult> ToggleActive(int id)
    {
        if (!IsAdmin())
            return Forbid();

        var (success, error) = await _authService.ToggleActiveAsync(id);
        if (!success)
            return NotFound(new { message = error });

        return Ok(new { message = "User active status toggled." });
    }

    // -----------------------------------------------------------------------
    // POST /api/users/{id}/reset-password
    // -----------------------------------------------------------------------
    /// <summary>
    /// Admin-initiated password reset.
    /// Sets MustChangePassword = true and clears PasswordChangedAt so expiry
    /// tracking restarts from the user's next voluntary change.
    /// </summary>
    [HttpPost("{id:int}/reset-password")]
    public async Task<IActionResult> ResetPassword(
        int id,
        [FromBody] AdminResetPasswordRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        var (success, error) = await _authService.AdminResetPasswordAsync(id, request);
        if (!success)
            return BadRequest(new { message = error });

        return Ok(new { message = "Password reset successfully." });
    }

}

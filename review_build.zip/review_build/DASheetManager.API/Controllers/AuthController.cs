using DASheetManager.Services.DTOs;
using DASheetManager.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DASheetManager.API.Controllers;

[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly IAuthService _authService;
    private readonly ICaptchaService _captchaService;
    private readonly CookieOptions _jwtCookieOptions;

    public AuthController(
        IAuthService authService,
        ICaptchaService captchaService,
        IWebHostEnvironment env)
    {
        _authService    = authService;
        _captchaService = captchaService;

        // Secure=true requires HTTPS — only enable in production.
        _jwtCookieOptions = new CookieOptions
        {
            HttpOnly = true,
            Secure   = !env.IsDevelopment(),
            SameSite = SameSiteMode.Strict,
            Path     = "/",
            MaxAge   = TimeSpan.FromHours(8)
        };
    }

    // -----------------------------------------------------------------------
    // GET /api/auth/captcha
    // -----------------------------------------------------------------------
    /// <summary>Generate a new math captcha question and return its token + question text.</summary>
    [HttpGet("captcha")]
    [AllowAnonymous]
    public IActionResult GenerateCaptcha()
    {
        var captcha = _captchaService.GenerateCaptcha();
        return Ok(captcha);
    }

    // -----------------------------------------------------------------------
    // POST /api/auth/login
    // -----------------------------------------------------------------------
    /// <summary>
    /// Authenticate with employee code or email + password.
    /// Validates the CAPTCHA before checking credentials.
    /// On success, writes the JWT to the 'da_jwt' HttpOnly cookie.
    /// </summary>
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        // Step 1 — validate captcha before touching the database.
        if (string.IsNullOrWhiteSpace(request.CaptchaToken) ||
            string.IsNullOrWhiteSpace(request.CaptchaAnswer))
            return BadRequest(new { message = "Captcha token and answer are required." });

        if (!_captchaService.ValidateCaptcha(request.CaptchaToken, request.CaptchaAnswer))
            return BadRequest(new { message = "Captcha answer is incorrect or has expired. Please try again." });

        // Step 2 — validate credentials.
        var response = await _authService.LoginAsync(request);
        if (response is null)
            return Unauthorized(new { message = "Invalid credentials or account is locked." });

        // Write JWT to HttpOnly cookie.
        Response.Cookies.Append("da_jwt", response.Token, _jwtCookieOptions);

        return Ok(new
        {
            user            = response.User,
            passwordExpired = response.PasswordExpired
        });
    }

    // -----------------------------------------------------------------------
    // POST /api/auth/logout
    // -----------------------------------------------------------------------
    /// <summary>Clear the 'da_jwt' cookie, effectively logging the user out.</summary>
    [HttpPost("logout")]
    [AllowAnonymous]
    public IActionResult Logout()
    {
        Response.Cookies.Delete("da_jwt", new CookieOptions { Path = "/" });
        return Ok(new { message = "Logged out successfully." });
    }

    // -----------------------------------------------------------------------
    // GET /api/auth/me
    // -----------------------------------------------------------------------
    /// <summary>Return the profile of the currently authenticated user.</summary>
    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> Me()
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var user = await _authService.GetUserByIdAsync(userId.Value);
        if (user is null)
            return NotFound(new { message = "User not found." });

        return Ok(user);
    }

    // -----------------------------------------------------------------------
    // POST /api/auth/change-password
    // -----------------------------------------------------------------------
    /// <summary>Change the password for the currently authenticated user.</summary>
    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest request)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var (success, error) = await _authService.ChangePasswordAsync(userId.Value, request);
        if (!success)
            return BadRequest(new { message = error });

        return Ok(new { message = "Password changed successfully." });
    }

}

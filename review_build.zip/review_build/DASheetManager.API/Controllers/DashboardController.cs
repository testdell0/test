using DASheetManager.Data.Repositories;
using DASheetManager.Services.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DASheetManager.API.Controllers;

[Route("api/dashboard")]
[Authorize]
public class DashboardController : ApiControllerBase
{
    private readonly IUnitOfWork _uow;

    public DashboardController(IUnitOfWork uow)
    {
        _uow = uow;
    }

    // -----------------------------------------------------------------------
    // GET /api/dashboard/stats
    // -----------------------------------------------------------------------
    /// <summary>
    /// Return aggregate counts for the dashboard.
    ///
    /// - Admins: total published templates + total active users.
    /// - Regular users: all counts are 0.
    /// </summary>
    [HttpGet("stats")]
    public async Task<IActionResult> GetStats()
    {
        var currentUserId = GetCurrentUserId();
        if (currentUserId is null)
            return Unauthorized();

        bool isAdmin = IsAdmin();

        int templateCount = 0;
        int userCount     = 0;

        if (isAdmin)
        {
            templateCount = await _uow.Templates.CountAsync(t => t.Status == "Published");
            userCount     = await _uow.Users.CountAsync(u => u.IsActive);
        }

        var stats = new DashboardStatsDto(templateCount, userCount);
        return Ok(stats);
    }
}

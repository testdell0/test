using DASheetManager.Services.DTOs;
using DASheetManager.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DASheetManager.API.Controllers;

[Route("api/templates")]
[Authorize]
public class TemplateController : ApiControllerBase
{
    private readonly ITemplateService _templateService;

    public TemplateController(ITemplateService templateService)
    {
        _templateService = templateService;
    }

    // ── Queries ────────────────────────────────────────────────────────────

    /// <summary>GET /api/templates — All templates (admin) or Published only (user).</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var templates = await _templateService.GetAllAsync(publishedOnly: !IsAdmin());
        return Ok(templates);
    }

    /// <summary>GET /api/templates/{id} — Template detail with categories + params.</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var template = await _templateService.GetByIdAsync(id);
        return template == null
            ? NotFound(new { error = $"Template {id} not found." })
            : Ok(template);
    }

    // ── Mutations (Admin-only) ──────────────────────────────────────────────

    /// <summary>POST /api/templates — Create a new Draft template.</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTemplateRequest request)
    {
        if (!IsAdmin()) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Name))
            return BadRequest(new { error = "Template name is required." });

        try
        {
            var template = await _templateService.CreateAsync(request, GetCurrentUserId() ?? 0);
            return Ok(template);
        }
        catch (InvalidOperationException ex) { return UnprocessableEntity(new { error = ex.Message }); }
    }

    /// <summary>PUT /api/templates/{id} — Update template (Draft only).</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateTemplateRequest request)
    {
        if (!IsAdmin()) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Name))
            return BadRequest(new { error = "Template name is required." });

        try
        {
            var template = await _templateService.UpdateAsync(id, request, GetCurrentUserId() ?? 0);
            return Ok(template);
        }
        catch (KeyNotFoundException ex)      { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return UnprocessableEntity(new { error = ex.Message }); }
    }

    /// <summary>DELETE /api/templates/{id} — Delete a Draft template.</summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        if (!IsAdmin()) return Forbid();

        try
        {
            await _templateService.DeleteAsync(id, GetCurrentUserId() ?? 0);
            return NoContent();
        }
        catch (KeyNotFoundException ex)      { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return UnprocessableEntity(new { error = ex.Message }); }
    }

    /// <summary>POST /api/templates/{id}/publish — Publish template (validates weightage = 100).</summary>
    [HttpPost("{id:int}/publish")]
    public async Task<IActionResult> Publish(int id)
    {
        if (!IsAdmin()) return Forbid();

        try
        {
            await _templateService.PublishAsync(id, GetCurrentUserId() ?? 0);
            return Ok(new { message = "Template published." });
        }
        catch (KeyNotFoundException ex)      { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return UnprocessableEntity(new { error = ex.Message }); }
    }

    /// <summary>POST /api/templates/{id}/unpublish — Revert template to Draft.</summary>
    [HttpPost("{id:int}/unpublish")]
    public async Task<IActionResult> Unpublish(int id)
    {
        if (!IsAdmin()) return Forbid();

        try
        {
            await _templateService.UnpublishAsync(id, GetCurrentUserId() ?? 0);
            return Ok(new { message = "Template unpublished." });
        }
        catch (KeyNotFoundException ex)      { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return UnprocessableEntity(new { error = ex.Message }); }
    }
}

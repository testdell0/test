namespace DASheetManager.Services.DTOs;

/// <summary>
/// Aggregate statistics shown on the dashboard.
/// For non-admin users, both counts are 0.
/// </summary>
public record DashboardStatsDto(
    int TemplateCount,
    int UserCount);

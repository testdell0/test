namespace DASheetManager.Services.DTOs;

// ---------------------------------------------------------------------------
// User management DTOs
// ---------------------------------------------------------------------------

public record CreateUserRequest(
    string EmployeeCode,
    string FullName,
    string Email,
    string Role,
    string Password);

/// <summary>Wraps a list of <see cref="CreateUserRequest"/> for bulk creation.</summary>
public record BulkCreateUserRequest(List<CreateUserRequest> Users);

/// <summary>Result for a single user in a bulk-create operation.</summary>
public record UserCreateResult(
    string EmployeeCode,
    bool Success,
    string? Error);

/// <summary>Aggregated result returned by the bulk-create endpoint.</summary>
public record BulkCreateResult(List<UserCreateResult> Results);

/// <summary>Payload for bulk user deletion.</summary>
public record BulkDeleteRequest(List<int> UserIds);

/// <summary>Result returned by the bulk-delete endpoint.</summary>
public record BulkDeleteResult(
    int Deleted,
    List<int> Failed,
    string? Error);

using System.Text.RegularExpressions;

namespace DASheetManager.Services.DTOs;

// ---------------------------------------------------------------------------
// Request DTOs
// ---------------------------------------------------------------------------

/// <summary>
/// Login payload. <see cref="Identifier"/> accepts either an employee code
/// or an email address — the service resolves which one was supplied.
/// </summary>
public record LoginRequest(
    string Identifier,
    string Password,
    string CaptchaToken,
    string CaptchaAnswer);

public record ChangePasswordRequest(
    string CurrentPassword,
    string NewPassword);

public record AdminResetPasswordRequest(
    string NewPassword);

// ---------------------------------------------------------------------------
// Response DTOs
// ---------------------------------------------------------------------------

public record LoginResponse(
    string Token,
    UserDto User,
    bool PasswordExpired);

public record UserDto(
    int UserId,
    string EmployeeCode,
    string FullName,
    string Email,
    string Role,
    bool MustChangePassword,
    bool IsActive);

public record CaptchaResponse(
    string Token,
    string Question);

// ---------------------------------------------------------------------------
// Password policy
// ---------------------------------------------------------------------------

/// <summary>
/// Central definition of password rules.
/// All validation goes through <see cref="Validate"/> so rules are enforced
/// consistently at creation time, change-password time, and reset time.
/// </summary>
public static class PasswordPolicy
{
    // Rules:
    // - 8–64 characters
    // - At least one uppercase letter (A-Z)
    // - At least one lowercase letter (a-z)
    // - At least one digit (0-9)
    // - At least one special character: !@#$%^&*()_+-=[]{}|;':",./<>?
    // - No spaces allowed

    private const int MinLength = 8;
    private const int MaxLength = 64;

    private static readonly Regex HasUppercase   = new(@"[A-Z]",              RegexOptions.Compiled);
    private static readonly Regex HasLowercase   = new(@"[a-z]",              RegexOptions.Compiled);
    private static readonly Regex HasDigit       = new(@"[0-9]",              RegexOptions.Compiled);
    private static readonly Regex HasSpecial     = new(@"[!@#$%^&*()\-_=+\[\]{}|;':"",./<>?]", RegexOptions.Compiled);
    private static readonly Regex HasSpace       = new(@"\s",                 RegexOptions.Compiled);

    /// <summary>
    /// Validate a plaintext password against the policy.
    /// Returns <c>(true, null)</c> on success, or <c>(false, errorMessage)</c> on failure.
    /// </summary>
    public static (bool Valid, string? Error) Validate(string password)
    {
        if (string.IsNullOrEmpty(password))
            return (false, "Password is required.");

        if (password.Length < MinLength)
            return (false, $"Password must be at least {MinLength} characters long.");

        if (password.Length > MaxLength)
            return (false, $"Password must not exceed {MaxLength} characters.");

        if (HasSpace.IsMatch(password))
            return (false, "Password must not contain spaces.");

        if (!HasUppercase.IsMatch(password))
            return (false, "Password must contain at least one uppercase letter (A-Z).");

        if (!HasLowercase.IsMatch(password))
            return (false, "Password must contain at least one lowercase letter (a-z).");

        if (!HasDigit.IsMatch(password))
            return (false, "Password must contain at least one digit (0-9).");

        if (!HasSpecial.IsMatch(password))
            return (false, "Password must contain at least one special character (!@#$%^&*()_+-=[]{}|;':\",./<>?).");

        return (true, null);
    }
}

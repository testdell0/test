using DASheetManager.Services.DTOs;

namespace DASheetManager.Services.Interfaces;

public interface ITemplateService
{
    /// <summary>Returns all templates. When publishedOnly = true, only Published templates are returned (for regular users).</summary>
    Task<List<TemplateListDto>> GetAllAsync(bool publishedOnly = false);

    /// <summary>Returns full template detail including categories and params, or null if not found.</summary>
    Task<TemplateDetailDto?> GetByIdAsync(int templateId);

    /// <summary>Creates a new Draft template with the supplied categories/params.</summary>
    Task<TemplateDetailDto> CreateAsync(CreateTemplateRequest request, int userId);

    /// <summary>
    /// Full replace-update: name/type/description + category/param diff.
    /// Only allowed while template is in Draft status.
    /// </summary>
    Task<TemplateDetailDto> UpdateAsync(int templateId, UpdateTemplateRequest request, int userId);

    /// <summary>Deletes a Draft template. Throws if template is Published or has sheets referencing it.</summary>
    Task DeleteAsync(int templateId, int userId);

    /// <summary>
    /// Transitions template from Draft → Published.
    /// Validates total weightage across all params == 100.
    /// </summary>
    Task PublishAsync(int templateId, int userId);

    /// <summary>Transitions template from Published → Draft.</summary>
    Task UnpublishAsync(int templateId, int userId);
}

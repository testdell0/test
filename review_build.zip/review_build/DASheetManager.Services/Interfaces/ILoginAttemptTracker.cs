namespace DASheetManager.Services.Interfaces;

/// <summary>
/// Tracks consecutive failed login attempts per identifier (employee code or email)
/// so that brute-force protection can be applied.
/// Implementations are registered as <b>Singleton</b>.
/// </summary>
public interface ILoginAttemptTracker
{
    /// <summary>Increment the failure counter for <paramref name="identifier"/>.</summary>
    void RecordFailure(string identifier);

    /// <summary>Reset the failure counter after a successful login.</summary>
    void ResetFailures(string identifier);

    /// <summary>
    /// Return the number of consecutive failures recorded for <paramref name="identifier"/>
    /// within the current tracking window.
    /// </summary>
    int GetFailureCount(string identifier);

    /// <summary>
    /// Returns <c>true</c> when the identifier has exceeded the maximum allowed failures
    /// and is temporarily locked out.
    /// </summary>
    bool IsLockedOut(string identifier);
}

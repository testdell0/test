using DASheetManager.Services.DTOs;

namespace DASheetManager.Services.Interfaces;

/// <summary>
/// Generates and validates simple math-based CAPTCHAs to deter automated login attempts.
/// Implementations should be registered as <b>Singleton</b> because they manage their own
/// in-process cache of pending tokens.
/// </summary>
public interface ICaptchaService
{
    /// <summary>
    /// Generate a new math question (e.g. "7 + 3 = ?"), persist the answer in cache
    /// against a fresh GUID token, and return both to the caller.
    /// </summary>
    CaptchaResponse GenerateCaptcha();

    /// <summary>
    /// Check that <paramref name="answer"/> matches the cached answer for <paramref name="token"/>
    /// and that the token has not expired (5-minute TTL).
    /// Consumes the token on success so it cannot be reused.
    /// </summary>
    /// <returns><c>true</c> if the answer is correct and the token is valid; otherwise <c>false</c>.</returns>
    bool ValidateCaptcha(string token, string answer);
}

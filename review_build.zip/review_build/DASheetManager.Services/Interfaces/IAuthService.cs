using DASheetManager.Services.DTOs;

namespace DASheetManager.Services.Interfaces;

/// <summary>
/// Authentication and user-management operations.
/// </summary>
public interface IAuthService
{
    /// <summary>
    /// Authenticate a user. <paramref name="request"/>.Identifier may be either an
    /// employee code or an email address.
    /// Returns null when credentials are invalid.
    /// </summary>
    Task<LoginResponse?> LoginAsync(LoginRequest request);

    /// <summary>
    /// Change the password for the currently authenticated user.
    /// Validates the current password and enforces the <see cref="PasswordPolicy"/>.
    /// Sets <c>PasswordChangedAt</c> to UtcNow and clears <c>MustChangePassword</c>.
    /// </summary>
    Task<(bool Success, string? Error)> ChangePasswordAsync(int userId, ChangePasswordRequest request);

    /// <summary>Return a <see cref="UserDto"/> for the given user ID. Returns null if not found.</summary>
    Task<UserDto?> GetUserByIdAsync(int userId);

    /// <summary>List all users (admin usage).</summary>
    Task<IEnumerable<UserDto>> GetAllUsersAsync();

    /// <summary>
    /// Create a single user account. Validates the password against <see cref="PasswordPolicy"/>.
    /// Returns the new <see cref="UserDto"/> or an error message.
    /// </summary>
    Task<(UserDto? User, string? Error)> CreateUserAsync(CreateUserRequest request);

    /// <summary>
    /// Bulk-create users. Never throws — each row either succeeds or records an error.
    /// </summary>
    Task<BulkCreateResult> BulkCreateUsersAsync(BulkCreateUserRequest request);

    /// <summary>
    /// Bulk-delete users. The caller's own user ID must be supplied so it is excluded.
    /// Never throws.
    /// </summary>
    Task<BulkDeleteResult> BulkDeleteUsersAsync(BulkDeleteRequest request, int currentUserId);

    /// <summary>Toggle the <c>IsActive</c> flag for the given user.</summary>
    Task<(bool Success, string? Error)> ToggleActiveAsync(int userId);

    /// <summary>
    /// Admin-initiated password reset.
    /// Sets <c>PasswordChangedAt = null</c> (so expiry tracking restarts from the user's
    /// next voluntary change) and <c>MustChangePassword = true</c>.
    /// </summary>
    Task<(bool Success, string? Error)> AdminResetPasswordAsync(int userId, AdminResetPasswordRequest request);
}

using DASheetManager.Data.Entities;
using DASheetManager.Data.Repositories;
using DASheetManager.Services.DTOs;
using DASheetManager.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DASheetManager.Services.Implementations;

public class TemplateService : ITemplateService
{
    private readonly IUnitOfWork _uow;

    public TemplateService(IUnitOfWork uow)
    {
        _uow = uow;
    }

    // ── Queries ────────────────────────────────────────────────────────────

    public async Task<List<TemplateListDto>> GetAllAsync(bool publishedOnly = false)
    {
        var query = _uow.Templates.Query()
            .Include(t => t.Creator)
            .Include(t => t.Categories);

        var filtered = publishedOnly
            ? query.Where(t => t.Status == "Published")
            : query;

        var templates = await filtered.OrderByDescending(t => t.UpdatedAt).ToListAsync();

        return templates.Select(t => new TemplateListDto
        {
            TemplateId    = t.TemplateId,
            Name          = t.Name,
            DaType        = t.DaType,
            Status        = t.Status,
            CreatedByName = t.Creator.FullName,
            CategoryCount = t.Categories.Count,
            CreatedAt     = t.CreatedAt,
            UpdatedAt     = t.UpdatedAt
        }).ToList();
    }

    public async Task<TemplateDetailDto?> GetByIdAsync(int templateId)
    {
        var template = await _uow.Templates.Query()
            .Include(t => t.Creator)
            .Include(t => t.Categories)
                .ThenInclude(c => c.Parameters)
            .FirstOrDefaultAsync(t => t.TemplateId == templateId);

        return template == null ? null : MapToDetailDto(template);
    }

    // ── Mutations ──────────────────────────────────────────────────────────

    public async Task<TemplateDetailDto> CreateAsync(CreateTemplateRequest request, int userId)
    {
        var template = new DaTemplate
        {
            Name        = request.Name.Trim(),
            DaType      = request.DaType,
            Description = request.Description,
            Status      = "Draft",
            CreatedBy   = userId
        };

        foreach (var catReq in request.Categories)
            template.Categories.Add(BuildCategory(catReq.Name, catReq.SortOrder,
                catReq.Parameters.Select(p => (p.Name, p.Weightage, p.SortOrder))));

        await _uow.Templates.AddAsync(template);
        await _uow.SaveChangesAsync();

        return (await GetByIdAsync(template.TemplateId))!;
    }

    public async Task<TemplateDetailDto> UpdateAsync(int templateId, UpdateTemplateRequest request, int userId)
    {
        var template = await _uow.Templates.Query()
            .Include(t => t.Categories)
                .ThenInclude(c => c.Parameters)
            .FirstOrDefaultAsync(t => t.TemplateId == templateId);

        if (template == null)
            throw new KeyNotFoundException($"Template {templateId} not found.");

        template.Name        = request.Name.Trim();
        template.DaType      = request.DaType;
        template.Description = request.Description;
        template.UpdatedAt   = DateTime.UtcNow;

        // Remove categories absent from request
        var keepCatIds = request.Categories
            .Where(c => c.CategoryId.HasValue)
            .Select(c => c.CategoryId!.Value)
            .ToHashSet();

        foreach (var cat in template.Categories.Where(c => !keepCatIds.Contains(c.CategoryId)).ToList())
            _uow.TemplateCategories.Remove(cat);

        foreach (var catReq in request.Categories)
        {
            if (catReq.CategoryId.HasValue)
            {
                var category   = template.Categories.First(c => c.CategoryId == catReq.CategoryId.Value);
                category.Name      = catReq.Name;
                category.SortOrder = catReq.SortOrder;

                var keepParamIds = catReq.Parameters
                    .Where(p => p.ParamId.HasValue)
                    .Select(p => p.ParamId!.Value)
                    .ToHashSet();

                foreach (var param in category.Parameters.Where(p => !keepParamIds.Contains(p.ParamId)).ToList())
                    _uow.TemplateJudgmentParams.Remove(param);

                foreach (var paramReq in catReq.Parameters)
                {
                    if (paramReq.ParamId.HasValue)
                    {
                        var existing       = category.Parameters.First(p => p.ParamId == paramReq.ParamId.Value);
                        existing.Name      = paramReq.Name;
                        existing.Weightage = paramReq.Weightage;
                        existing.SortOrder = paramReq.SortOrder;
                    }
                    else
                    {
                        category.Parameters.Add(new DaTemplateJudgmentParam
                        {
                            Name      = paramReq.Name,
                            Weightage = paramReq.Weightage,
                            SortOrder = paramReq.SortOrder
                        });
                    }
                }
            }
            else
            {
                template.Categories.Add(BuildCategory(catReq.Name, catReq.SortOrder,
                    catReq.Parameters.Select(p => (p.Name, p.Weightage, p.SortOrder))));
            }
        }

        await _uow.SaveChangesAsync();
        return (await GetByIdAsync(templateId))!;
    }

    public async Task DeleteAsync(int templateId, int userId)
    {
        var template = await _uow.Templates.GetByIdAsync(templateId);
        if (template == null)
            throw new KeyNotFoundException($"Template {templateId} not found.");

        _uow.Templates.Remove(template);
        await _uow.SaveChangesAsync();
    }

    public async Task PublishAsync(int templateId, int userId)
    {
        var template = await _uow.Templates.Query()
            .Include(t => t.Categories)
                .ThenInclude(c => c.Parameters)
            .FirstOrDefaultAsync(t => t.TemplateId == templateId);

        if (template == null)
            throw new KeyNotFoundException($"Template {templateId} not found.");

        if (!template.Categories.Any())
            throw new InvalidOperationException("Template must have at least one category.");

        var totalWeightage = template.Categories.SelectMany(c => c.Parameters).Sum(p => p.Weightage);
        if (totalWeightage != 100)
            throw new InvalidOperationException($"Total weightage must equal 100%. Current: {totalWeightage}%.");

        template.Status    = "Published";
        template.UpdatedAt = DateTime.UtcNow;
        await _uow.SaveChangesAsync();
    }

    public async Task UnpublishAsync(int templateId, int userId)
    {
        var template = await _uow.Templates.GetByIdAsync(templateId);
        if (template == null)
            throw new KeyNotFoundException($"Template {templateId} not found.");

        template.Status    = "Draft";
        template.UpdatedAt = DateTime.UtcNow;
        await _uow.SaveChangesAsync();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    /// <summary>
    /// Constructs a new DaTemplateCategory with its parameters.
    /// Called from both CreateAsync and the new-category branch of UpdateAsync.
    /// </summary>
    private static DaTemplateCategory BuildCategory(
        string name,
        int sortOrder,
        IEnumerable<(string Name, int Weightage, int SortOrder)> parameters)
    {
        var category = new DaTemplateCategory { Name = name, SortOrder = sortOrder };
        foreach (var p in parameters)
            category.Parameters.Add(new DaTemplateJudgmentParam
            {
                Name      = p.Name,
                Weightage = p.Weightage,
                SortOrder = p.SortOrder
            });
        return category;
    }

    // ── Mapping ────────────────────────────────────────────────────────────

    private static TemplateDetailDto MapToDetailDto(DaTemplate t) => new()
    {
        TemplateId    = t.TemplateId,
        Name          = t.Name,
        DaType        = t.DaType,
        Description   = t.Description,
        Status        = t.Status,
        CreatedByName = t.Creator?.FullName ?? string.Empty,
        CreatedAt     = t.CreatedAt,
        UpdatedAt     = t.UpdatedAt,
        Categories    = t.Categories.OrderBy(c => c.SortOrder).Select(c => new TemplateCategoryDto
        {
            CategoryId = c.CategoryId,
            Name       = c.Name,
            SortOrder  = c.SortOrder,
            Parameters = c.Parameters.OrderBy(p => p.SortOrder).Select(p => new TemplateParamDto
            {
                ParamId   = p.ParamId,
                Name      = p.Name,
                Weightage = p.Weightage,
                SortOrder = p.SortOrder
            }).ToList()
        }).ToList()
    };
}

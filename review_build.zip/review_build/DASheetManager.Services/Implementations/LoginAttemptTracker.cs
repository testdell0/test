using DASheetManager.Services.Interfaces;
using System.Collections.Concurrent;

namespace DASheetManager.Services.Implementations;

/// <summary>
/// Thread-safe, in-process tracker for consecutive failed login attempts.
///
/// Policy:
///   - After <see cref="MaxFailures"/> consecutive failures the account is locked
///     for <see cref="LockoutDuration"/>.
///   - A successful login resets the counter immediately.
///
/// Registered as Singleton so state persists across requests.
/// </summary>
public class LoginAttemptTracker : ILoginAttemptTracker
{
    // Maximum consecutive failures before a lockout is applied.
    private const int MaxFailures = 5;

    // Duration of the lockout window.
    private static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(15);

    private record AttemptRecord(int Count, DateTime LastFailure);

    private readonly ConcurrentDictionary<string, AttemptRecord> _records = new();

    /// <inheritdoc/>
    public void RecordFailure(string identifier)
    {
        _records.AddOrUpdate(
            identifier.ToLowerInvariant(),
            _ => new AttemptRecord(1, DateTime.UtcNow),
            (_, existing) => existing with { Count = existing.Count + 1, LastFailure = DateTime.UtcNow });
    }

    /// <inheritdoc/>
    public void ResetFailures(string identifier) =>
        _records.TryRemove(identifier.ToLowerInvariant(), out _);

    /// <inheritdoc/>
    public int GetFailureCount(string identifier)
    {
        if (_records.TryGetValue(identifier.ToLowerInvariant(), out var record))
            return record.Count;
        return 0;
    }

    /// <inheritdoc/>
    public bool IsLockedOut(string identifier)
    {
        if (!_records.TryGetValue(identifier.ToLowerInvariant(), out var record))
            return false;

        if (record.Count < MaxFailures)
            return false;

        // Lockout window: check if enough time has passed since last failure.
        if (DateTime.UtcNow - record.LastFailure < LockoutDuration)
            return true;

        // Lockout window has expired — automatically reset.
        _records.TryRemove(identifier.ToLowerInvariant(), out _);
        return false;
    }
}

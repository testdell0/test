using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
using DASheetManager.Data.Entities;
using DASheetManager.Data.Repositories;
using DASheetManager.Services.DTOs;
using DASheetManager.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace DASheetManager.Services.Implementations;

/// <summary>
/// Handles authentication, JWT issuance, password management, and user CRUD.
/// </summary>
public class AuthService : IAuthService
{
    private readonly IUnitOfWork _uow;
    private readonly IConfiguration _config;
    private readonly ILoginAttemptTracker _loginTracker;

    // Password expiry: 90 days after last change.
    private const int PasswordExpiryDays = 90;

    public AuthService(
        IUnitOfWork uow,
        IConfiguration config,
        ILoginAttemptTracker loginTracker)
    {
        _uow = uow;
        _config = config;
        _loginTracker = loginTracker;
    }

    // -----------------------------------------------------------------------
    // Login
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<LoginResponse?> LoginAsync(LoginRequest request)
    {
        var identifier = request.Identifier?.Trim() ?? string.Empty;

        // Check for lockout before any DB query.
        if (_loginTracker.IsLockedOut(identifier))
            return null;

        // Look up by employee code OR email — whichever matches.
        var user = await _uow.Users.FindAsync(u =>
            u.EmployeeCode == identifier || u.Email == identifier);

        if (user is null || !user.IsActive || user.PasswordHash is null)
        {
            _loginTracker.RecordFailure(identifier);
            return null;
        }

        // Verify password using BCrypt.
        bool passwordOk = BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash);
        if (!passwordOk)
        {
            _loginTracker.RecordFailure(identifier);
            return null;
        }

        // Successful auth — reset failure counter.
        _loginTracker.ResetFailures(identifier);

        // ------------------------------------------------------------------
        // Password expiry check (90-day policy)
        // ------------------------------------------------------------------
        bool passwordExpired = false;
        if (user.PasswordChangedAt is null ||
            user.PasswordChangedAt.Value.AddDays(PasswordExpiryDays) < DateTime.UtcNow)
        {
            // Force the user to change their password.
            user.MustChangePassword = true;
            user.UpdatedAt = DateTime.UtcNow;
            _uow.Users.Update(user);
            await _uow.SaveChangesAsync();
            passwordExpired = true;
        }

        var token = GenerateJwt(user);
        var dto   = MapToDto(user);
        return new LoginResponse(token, dto, passwordExpired);
    }

    // -----------------------------------------------------------------------
    // Password management
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<(bool Success, string? Error)> ChangePasswordAsync(
        int userId,
        ChangePasswordRequest request)
    {
        var user = await _uow.Users.GetByIdAsync(userId);
        if (user is null)
            return (false, "User not found.");

        // Verify current password.
        if (user.PasswordHash is null ||
            !BCrypt.Net.BCrypt.Verify(request.CurrentPassword, user.PasswordHash))
            return (false, "Current password is incorrect.");

        // Validate the new password against policy.
        var (valid, policyError) = PasswordPolicy.Validate(request.NewPassword);
        if (!valid)
            return (false, policyError);

        user.PasswordHash       = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);
        user.MustChangePassword = false;
        user.PasswordChangedAt  = DateTime.UtcNow;
        user.UpdatedAt          = DateTime.UtcNow;

        _uow.Users.Update(user);
        await _uow.SaveChangesAsync();
        return (true, null);
    }

    /// <inheritdoc/>
    public async Task<(bool Success, string? Error)> AdminResetPasswordAsync(
        int userId,
        AdminResetPasswordRequest request)
    {
        var user = await _uow.Users.GetByIdAsync(userId);
        if (user is null)
            return (false, "User not found.");

        var (valid, policyError) = PasswordPolicy.Validate(request.NewPassword);
        if (!valid)
            return (false, policyError);

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);

        // Null out PasswordChangedAt so expiry tracking restarts from the
        // user's next voluntary change, not from the admin reset.
        user.PasswordChangedAt  = null;
        user.MustChangePassword = true;
        user.UpdatedAt          = DateTime.UtcNow;

        _uow.Users.Update(user);
        await _uow.SaveChangesAsync();
        return (true, null);
    }

    // -----------------------------------------------------------------------
    // User queries
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<UserDto?> GetUserByIdAsync(int userId)
    {
        var user = await _uow.Users.GetByIdAsync(userId);
        return user is null ? null : MapToDto(user);
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<UserDto>> GetAllUsersAsync()
    {
        var users = await _uow.Users.FindAllAsync(_ => true);
        return users.Select(MapToDto);
    }

    // -----------------------------------------------------------------------
    // User creation
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<(UserDto? User, string? Error)> CreateUserAsync(CreateUserRequest request)
    {
        // Validate password.
        var (valid, policyError) = PasswordPolicy.Validate(request.Password);
        if (!valid)
            return (null, policyError);

        // Check for duplicate employee code.
        if (await _uow.Users.AnyAsync(u => u.EmployeeCode == request.EmployeeCode))
            return (null, $"Employee code '{request.EmployeeCode}' is already in use.");

        // Check for duplicate email.
        if (await _uow.Users.AnyAsync(u => u.Email == request.Email))
            return (null, $"Email '{request.Email}' is already in use.");

        // Validate role.
        if (request.Role != "Admin" && request.Role != "User")
            return (null, "Role must be 'Admin' or 'User'.");

        var now = DateTime.UtcNow;
        var user = new DaUser
        {
            EmployeeCode      = request.EmployeeCode.Trim(),
            FullName          = request.FullName.Trim(),
            Email             = request.Email.Trim().ToLowerInvariant(),
            Role              = request.Role,
            PasswordHash      = BCrypt.Net.BCrypt.HashPassword(request.Password),
            MustChangePassword = true,   // Force password change on first login.
            PasswordChangedAt = null,    // Not yet changed by the user.
            IsActive          = true,
            CreatedAt         = now,
            UpdatedAt         = now
        };

        await _uow.Users.AddAsync(user);
        await _uow.SaveChangesAsync();
        return (MapToDto(user), null);
    }

    // -----------------------------------------------------------------------
    // Bulk create
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<BulkCreateResult> BulkCreateUsersAsync(BulkCreateUserRequest request)
    {
        var results = new List<UserCreateResult>();

        foreach (var item in request.Users)
        {
            try
            {
                var (user, error) = await CreateUserAsync(item);
                if (user is not null)
                    results.Add(new UserCreateResult(item.EmployeeCode, true, null));
                else
                    results.Add(new UserCreateResult(item.EmployeeCode, false, error));
            }
            catch (Exception ex)
            {
                // Catch unexpected failures so the whole batch isn't aborted.
                results.Add(new UserCreateResult(item.EmployeeCode, false, ex.Message));
            }
        }

        return new BulkCreateResult(results);
    }

    // -----------------------------------------------------------------------
    // Bulk delete
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<BulkDeleteResult> BulkDeleteUsersAsync(
        BulkDeleteRequest request,
        int currentUserId)
    {
        int deleted = 0;
        var failed  = new List<int>();
        string? globalError = null;

        foreach (var id in request.UserIds)
        {
            // Cannot delete yourself.
            if (id == currentUserId)
            {
                failed.Add(id);
                continue;
            }

            try
            {
                var user = await _uow.Users.GetByIdAsync(id);
                if (user is null)
                {
                    failed.Add(id);
                    continue;
                }

                _uow.Users.Remove(user);
                await _uow.SaveChangesAsync();
                deleted++;
            }
            catch (Exception ex)
            {
                failed.Add(id);
                // Surface the first unexpected error as context for the caller.
                globalError ??= ex.Message;
            }
        }

        return new BulkDeleteResult(deleted, failed, globalError);
    }

    // -----------------------------------------------------------------------
    // Toggle active
    // -----------------------------------------------------------------------

    /// <inheritdoc/>
    public async Task<(bool Success, string? Error)> ToggleActiveAsync(int userId)
    {
        var user = await _uow.Users.GetByIdAsync(userId);
        if (user is null)
            return (false, "User not found.");

        user.IsActive  = !user.IsActive;
        user.UpdatedAt = DateTime.UtcNow;

        _uow.Users.Update(user);
        await _uow.SaveChangesAsync();
        return (true, null);
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    private string GenerateJwt(DaUser user)
    {
        var key     = _config["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is not configured.");
        var issuer  = _config["Jwt:Issuer"] ?? "DASheetManager";
        var audience = _config["Jwt:Audience"] ?? "DASheetManager";

        var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
        var credentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim("employeeCode",                user.EmployeeCode),
            new Claim(ClaimTypes.Role,               user.Role),
            new Claim(JwtRegisteredClaimNames.Jti,   Guid.NewGuid().ToString())
        };

        var token = new JwtSecurityToken(
            issuer:   issuer,
            audience: audience,
            claims:   claims,
            expires:  DateTime.UtcNow.AddHours(8),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static UserDto MapToDto(DaUser u) => new(
        u.UserId,
        u.EmployeeCode,
        u.FullName,
        u.Email,
        u.Role,
        u.MustChangePassword,
        u.IsActive);
}

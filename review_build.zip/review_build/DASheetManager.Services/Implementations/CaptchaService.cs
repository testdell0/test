using DASheetManager.Services.DTOs;
using DASheetManager.Services.Interfaces;
using Microsoft.Extensions.Caching.Memory;

namespace DASheetManager.Services.Implementations;

/// <summary>
/// Generates simple addition/subtraction math questions and validates answers
/// using an in-process <see cref="IMemoryCache"/> with a 5-minute sliding expiry.
///
/// Registered as Singleton so the cache outlives individual HTTP requests.
/// </summary>
public class CaptchaService : ICaptchaService
{
    private readonly IMemoryCache _cache;
    private readonly Random _rng = new();

    // Cache entry options: each token expires 5 minutes after it is created.
    private static readonly MemoryCacheEntryOptions CacheOptions =
        new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(5));

    // Cache key prefix to avoid collision with other cached items.
    private const string KeyPrefix = "captcha:";

    public CaptchaService(IMemoryCache cache)
    {
        _cache = cache;
    }

    /// <inheritdoc/>
    public CaptchaResponse GenerateCaptcha()
    {
        // Pick two operands and an operator to keep math suitable for any user.
        int a = _rng.Next(1, 20);
        int b = _rng.Next(1, 20);

        // Use addition and subtraction only; guarantee non-negative result for subtraction.
        bool useAddition = _rng.Next(0, 2) == 0;
        string question;
        int answer;

        if (useAddition)
        {
            question = $"{a} + {b} = ?";
            answer = a + b;
        }
        else
        {
            // Ensure a >= b so the result is positive.
            if (a < b) (a, b) = (b, a);
            question = $"{a} - {b} = ?";
            answer = a - b;
        }

        var token = Guid.NewGuid().ToString("N");
        _cache.Set(KeyPrefix + token, answer.ToString(), CacheOptions);

        return new CaptchaResponse(token, question);
    }

    /// <inheritdoc/>
    public bool ValidateCaptcha(string token, string answer)
    {
        var key = KeyPrefix + token;

        if (!_cache.TryGetValue(key, out string? storedAnswer))
            return false; // Token not found or expired.

        bool correct = string.Equals(storedAnswer, answer?.Trim(), StringComparison.OrdinalIgnoreCase);

        // Consume the token regardless of correctness to prevent replay attacks.
        _cache.Remove(key);

        return correct;
    }
}

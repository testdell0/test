import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { CurrentUser } from '../types/da-types'

interface AuthState {
  user: CurrentUser | null
  isAuthenticated: boolean
  login(user: CurrentUser): void
  logout(): void
  setUser(user: CurrentUser): void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,

      login(user: CurrentUser) {
        set({ user, isAuthenticated: true })
      },

      logout() {
        set({ user: null, isAuthenticated: false })
      },

      setUser(user: CurrentUser) {
        set({ user, isAuthenticated: true })
      },
    }),
    {
      name: 'da-sheet-auth',
      // Only persist non-sensitive fields; the real session lives in the HttpOnly cookie.
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    },
  ),
)

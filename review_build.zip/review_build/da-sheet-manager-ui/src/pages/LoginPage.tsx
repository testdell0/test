import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { useQueryClient } from '@tanstack/react-query'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Eye, EyeOff, RefreshCw, AlertCircle } from 'lucide-react'
import { authApi } from '../api/auth'
import { useAuthStore } from '../store/authStore'
import type { CaptchaResponse } from '../types/da-types'
import { ApiError } from '../api/client'

// ---- Validation schema ----

const loginSchema = z.object({
  identifier: z.string().min(1, 'Employee code or email is required'),
  password: z.string().min(1, 'Password is required'),
  captchaAnswer: z.string().min(1, 'Please answer the captcha'),
})

type LoginFormValues = z.infer<typeof loginSchema>

// ---- Component ----

export function LoginPage() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const loginAction = useAuthStore((s) => s.login)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)

  const [captcha, setCaptcha] = useState<CaptchaResponse | null>(null)
  const [captchaLoading, setCaptchaLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)
  const [passwordExpired, setPasswordExpired] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const hasMounted = useRef(false)

  // If already logged in, go directly to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard', { replace: true })
    }
  }, [isAuthenticated, navigate])

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
  })

  // Fetch initial captcha on mount
  useEffect(() => {
    if (hasMounted.current) return
    hasMounted.current = true
    void fetchCaptcha()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function fetchCaptcha() {
    setCaptchaLoading(true)
    try {
      const c = await authApi.getCaptcha()
      setCaptcha(c)
      setValue('captchaAnswer', '')
    } catch {
      // Non-fatal; user can retry
    } finally {
      setCaptchaLoading(false)
    }
  }

  async function onSubmit(values: LoginFormValues) {
    if (!captcha) return
    setServerError(null)
    setPasswordExpired(false)
    setSubmitting(true)

    try {
      const { user, passwordExpired } = await authApi.login({
        identifier: values.identifier,
        password: values.password,
        captchaToken: captcha.token,
        captchaAnswer: values.captchaAnswer,
      })

      loginAction(user)

      // Seed the React Query cache so the stale useMe() query
      // doesn't refetch and race with navigation.
      queryClient.setQueryData(['me'], user)

      if (user.mustChangePassword || passwordExpired) {
        if (passwordExpired) {
          setPasswordExpired(true)
          setServerError('Your password has expired. Please change it to continue.')
        }
        navigate('/change-password', { replace: true })
      } else {
        navigate('/dashboard', { replace: true })
      }
    } catch (err) {
      // Refresh captcha on every failed attempt
      void fetchCaptcha()

      if (err instanceof ApiError) {
        if (err.status === 423) {
          setServerError(
            'Your account has been locked due to too many failed attempts. Contact your administrator.',
          )
        } else if (err.status === 401) {
          setServerError('Invalid credentials. Please check your employee code/email and password.')
        } else {
          setServerError(err.message || 'Login failed. Please try again.')
        }
      } else {
        setServerError('A network error occurred. Please try again.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-12">
      <div className="w-full max-w-md space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-brand-600">
            <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">DA Sheet Manager</h1>
          <p className="mt-1 text-sm text-gray-500">Sign in to your account</p>
        </div>

        {/* Card */}
        <div className="rounded-xl bg-white px-8 py-8 shadow-md">
          <h2 className="mb-6 text-lg font-semibold text-gray-800">Login</h2>

          {/* Server error */}
          {serverError && (
            <div className="mb-4 flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 px-4 py-3">
              <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-red-600" />
              <p className="text-sm text-red-700">{serverError}</p>
            </div>
          )}

          {/* Password expired notice */}
          {passwordExpired && (
            <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3">
              <p className="text-sm font-medium text-amber-800">
                Your password has expired. You will be redirected to change it.
              </p>
            </div>
          )}

          <form onSubmit={(e) => void handleSubmit(onSubmit)(e)} className="space-y-5" noValidate>
            {/* Identifier */}
            <div>
              <label
                htmlFor="identifier"
                className="mb-1.5 block text-sm font-medium text-gray-700"
              >
                Employee Code or Email
              </label>
              <input
                id="identifier"
                type="text"
                autoComplete="username"
                {...register('identifier')}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm placeholder-gray-400 shadow-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 disabled:bg-gray-50"
                placeholder="EMP001 or you@company.com"
              />
              {errors.identifier && (
                <p className="mt-1 text-xs text-red-600">{errors.identifier.message}</p>
              )}
            </div>

            {/* Password */}
            <div>
              <label
                htmlFor="password"
                className="mb-1.5 block text-sm font-medium text-gray-700"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  {...register('password')}
                  className="w-full rounded-md border border-gray-300 px-3 py-2 pr-10 text-sm placeholder-gray-400 shadow-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>
              )}
            </div>

            {/* Captcha */}
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="captchaAnswer" className="block text-sm font-medium text-gray-700">
                  Security Check
                </label>
                <button
                  type="button"
                  onClick={() => void fetchCaptcha()}
                  disabled={captchaLoading}
                  className="flex items-center gap-1 text-xs text-brand-600 hover:text-brand-700 disabled:opacity-50"
                >
                  <RefreshCw className={`h-3 w-3 ${captchaLoading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>

              <div className="mb-2 flex items-center justify-center rounded-md border border-gray-200 bg-gray-50 px-4 py-3">
                {captchaLoading ? (
                  <span className="text-sm text-gray-400">Generating captcha…</span>
                ) : captcha ? (
                  <span className="select-none font-mono text-lg font-bold tracking-widest text-gray-800">
                    {captcha.question}
                  </span>
                ) : (
                  <span className="text-sm text-red-500">
                    Failed to load captcha.{' '}
                    <button
                      type="button"
                      onClick={() => void fetchCaptcha()}
                      className="underline"
                    >
                      Retry
                    </button>
                  </span>
                )}
              </div>

              <input
                id="captchaAnswer"
                type="text"
                inputMode="numeric"
                {...register('captchaAnswer')}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
                placeholder="Enter the answer"
              />
              {errors.captchaAnswer && (
                <p className="mt-1 text-xs text-red-600">{errors.captchaAnswer.message}</p>
              )}
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={submitting || !captcha}
              className="w-full rounded-md bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-gray-400">
          &copy; {new Date().getFullYear()} DA Sheet Manager. All rights reserved.
        </p>
      </div>
    </div>
  )
}

import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useTemplate, useCreateTemplate, useUpdateTemplate } from '../hooks/useTemplates'
import type { CreateTemplateRequest, UpdateTemplateRequest } from '../types/da-types'

// ── Local form types ─────────────────────────────────────────────────────────

interface ParamForm {
  paramId?:  number   // undefined = new row
  name:      string
  weightage: number
}

interface CategoryForm {
  categoryId?: number  // undefined = new row
  name:        string
  sortOrder:   number
  parameters:  ParamForm[]
}

const WEIGHTAGE_OPTIONS = [5, 10, 15, 20, 25, 30] as const
const DA_TYPES          = ['License', 'Custom Development', 'SaaS', 'Other'] as const

// ── Helpers ──────────────────────────────────────────────────────────────────

function categoryTotal(cat: CategoryForm): number {
  return cat.parameters.reduce((sum, p) => sum + p.weightage, 0)
}

function allCategoriesValid(cats: CategoryForm[]): boolean {
  return (
    cats.length > 0 &&
    cats.every(c => c.name.trim().length > 0 && c.parameters.length > 0 && categoryTotal(c) === 100)
  )
}

function newCategory(sortOrder: number): CategoryForm {
  return { name: '', sortOrder, parameters: [{ name: '', weightage: 10 }] }
}

// ── TemplatePage (create + edit) ─────────────────────────────────────────────

export default function TemplatePage() {
  const { id }       = useParams<{ id: string }>()
  const templateId   = id ? Number(id) : undefined
  const isEdit       = templateId !== undefined
  const navigate     = useNavigate()

  const { data: existing }  = useTemplate(templateId ?? 0)
  const createMutation      = useCreateTemplate()
  const updateMutation      = useUpdateTemplate(templateId ?? 0)

  const [name, setName]       = useState('')
  const [daType, setDaType]   = useState<string>(DA_TYPES[0])
  const [description, setDescription] = useState('')
  const [categories, setCats] = useState<CategoryForm[]>([newCategory(1)])

  // Pre-fill form when editing
  useEffect(() => {
    if (isEdit && existing) {
      setName(existing.name)
      setDaType(existing.daType)
      setDescription(existing.description ?? '')
      setCats(
        existing.categories.map(c => ({
          categoryId: c.categoryId,
          name:       c.name,
          sortOrder:  c.sortOrder,
          parameters: c.parameters.map(p => ({
            paramId:   p.paramId,
            name:      p.name,
            weightage: p.weightage,
          })),
        }))
      )
    }
  }, [isEdit, existing])

  // ── Category helpers ──────────────────────────────────────────────────────

  function addCategory() {
    setCats(prev => [...prev, newCategory(prev.length + 1)])
  }

  function removeCategory(idx: number) {
    setCats(prev => prev.filter((_, i) => i !== idx))
  }

  function updateCategoryName(idx: number, value: string) {
    setCats(prev => prev.map((c, i) => i === idx ? { ...c, name: value } : c))
  }

  function addParam(catIdx: number) {
    setCats(prev =>
      prev.map((c, i) =>
        i === catIdx
          ? { ...c, parameters: [...c.parameters, { name: '', weightage: 10 }] }
          : c
      )
    )
  }

  function removeParam(catIdx: number, paramIdx: number) {
    setCats(prev =>
      prev.map((c, i) =>
        i === catIdx
          ? { ...c, parameters: c.parameters.filter((_, j) => j !== paramIdx) }
          : c
      )
    )
  }

  function updateParam(
    catIdx: number,
    paramIdx: number,
    field: keyof ParamForm,
    value: string | number
  ) {
    setCats(prev =>
      prev.map((c, i) =>
        i === catIdx
          ? {
              ...c,
              parameters: c.parameters.map((p, j) =>
                j === paramIdx ? { ...p, [field]: value } : p
              ),
            }
          : c
      )
    )
  }

  // ── Submit ────────────────────────────────────────────────────────────────

  async function handleSubmit() {
    if (!name.trim() || !allCategoriesValid(categories)) return

    const categoryPayload = categories.map((c, ci) => ({
      ...(c.categoryId ? { categoryId: c.categoryId } : {}),
      name:      c.name.trim(),
      sortOrder: ci + 1,
      parameters: c.parameters.map((p, pi) => ({
        ...(p.paramId ? { paramId: p.paramId } : {}),
        name:      p.name.trim(),
        weightage: p.weightage,
        sortOrder: pi + 1,
      })),
    }))

    if (isEdit) {
      await updateMutation.mutateAsync({
        name: name.trim(),
        daType,
        description: description || undefined,
        categories:  categoryPayload,
      } as UpdateTemplateRequest)
    } else {
      await createMutation.mutateAsync({
        name: name.trim(),
        daType,
        description: description || undefined,
        categories:  categoryPayload,
      } as CreateTemplateRequest)
    }

    navigate('/templates')
  }

  const isSaving = createMutation.isPending || updateMutation.isPending
  const canSave  = name.trim().length > 0 && allCategoriesValid(categories)
  const hasWeightageError = categories.some(c => c.parameters.length > 0 && categoryTotal(c) !== 100)

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div className="p-6 max-w-3xl space-y-6">
      {/* Breadcrumb / header */}
      <div className="flex items-center gap-3">
        <button
          className="text-sm text-gray-500 hover:text-gray-700"
          onClick={() => navigate('/templates')}
        >
          ← Templates
        </button>
        <h1 className="text-xl font-semibold text-gray-900">
          {isEdit ? 'Edit Template' : 'New Template'}
        </h1>
      </div>

      {/* Basic info */}
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2 space-y-1">
          <label className="block text-sm font-medium text-gray-700">
            Template Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            className="w-full border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="e.g. QCDMS Standard Evaluation"
            value={name}
            onChange={e => setName(e.target.value)}
          />
        </div>

        <div className="space-y-1">
          <label className="block text-sm font-medium text-gray-700">DA Type</label>
          <select
            className="w-full border rounded-md px-3 py-2 text-sm"
            value={daType}
            onChange={e => setDaType(e.target.value)}
          >
            {DA_TYPES.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>

        <div className="col-span-2 space-y-1">
          <label className="block text-sm font-medium text-gray-700">Description</label>
          <textarea
            className="w-full border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={2}
            placeholder="Optional description"
            value={description}
            onChange={e => setDescription(e.target.value)}
          />
        </div>
      </div>

      {/* Categories */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-gray-800">
            Categories <span className="text-xs text-gray-400 font-normal">(each must total 100%)</span>
          </h2>
          <button
            type="button"
            className="px-3 py-1.5 text-sm border rounded-md hover:bg-gray-50"
            onClick={addCategory}
          >
            + Add Category
          </button>
        </div>

        {categories.map((cat, ci) => {
          const total   = categoryTotal(cat)
          const totalOk = total === 100

          return (
            <div key={ci} className="border rounded-lg p-4 space-y-3 bg-white">
              {/* Category header row */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  className="flex-1 border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Category name (e.g. Quality)"
                  value={cat.name}
                  onChange={e => updateCategoryName(ci, e.target.value)}
                />
                <span
                  className={`px-2 py-0.5 text-xs font-medium rounded-full whitespace-nowrap ${
                    totalOk
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                  }`}
                >
                  {total}% / 100%
                </span>
                {categories.length > 1 && (
                  <button
                    type="button"
                    className="text-red-400 hover:text-red-600 text-sm px-1"
                    title="Remove category"
                    onClick={() => removeCategory(ci)}
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Parameters */}
              <div className="space-y-2 pl-2">
                {cat.parameters.map((param, pi) => (
                  <div key={pi} className="flex items-center gap-2">
                    <input
                      type="text"
                      className="flex-1 border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Parameter name"
                      value={param.name}
                      onChange={e => updateParam(ci, pi, 'name', e.target.value)}
                    />
                    <select
                      className="w-24 border rounded-md px-2 py-1.5 text-sm"
                      value={param.weightage}
                      onChange={e => updateParam(ci, pi, 'weightage', Number(e.target.value))}
                    >
                      {WEIGHTAGE_OPTIONS.map(w => (
                        <option key={w} value={w}>{w}%</option>
                      ))}
                    </select>
                    {cat.parameters.length > 1 && (
                      <button
                        type="button"
                        className="text-red-400 hover:text-red-600 text-sm px-1"
                        title="Remove parameter"
                        onClick={() => removeParam(ci, pi)}
                      >
                        ✕
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  className="text-sm text-blue-600 hover:underline"
                  onClick={() => addParam(ci)}
                >
                  + Add Parameter
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Validation notice */}
      {hasWeightageError && (
        <p className="text-sm text-red-600">
          All categories must have parameters whose weightages total exactly 100%.
        </p>
      )}

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-2">
        <button
          type="button"
          className="px-4 py-2 text-sm border rounded-md hover:bg-gray-50"
          onClick={() => navigate('/templates')}
        >
          Cancel
        </button>
        <button
          type="button"
          className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={handleSubmit}
          disabled={!canSave || isSaving}
        >
          {isSaving ? 'Saving…' : isEdit ? 'Save Changes' : 'Create Template'}
        </button>
      </div>
    </div>
  )
}

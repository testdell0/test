import { useNavigate } from 'react-router-dom'
import {
  useTemplates,
  useDeleteTemplate,
  usePublishTemplate,
  useUnpublishTemplate,
} from '../hooks/useTemplates'
import type { TemplateListItem } from '../types/da-types'

export default function TemplatesPage() {
  const navigate = useNavigate()
  const { data: templates = [], isLoading } = useTemplates()
  const deleteMutation    = useDeleteTemplate()
  const publishMutation   = usePublishTemplate()
  const unpublishMutation = useUnpublishTemplate()

  async function handleDelete(t: TemplateListItem) {
    if (!confirm(`Delete template "${t.name}"? This cannot be undone.`)) return
    await deleteMutation.mutateAsync(t.templateId)
  }

  async function handleTogglePublish(t: TemplateListItem) {
    if (t.status === 'Published') {
      await unpublishMutation.mutateAsync(t.templateId)
    } else {
      await publishMutation.mutateAsync(t.templateId)
    }
  }

  if (isLoading) {
    return <div className="p-8 text-center text-gray-500">Loading templates…</div>
  }

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900">Templates</h1>
        <button
          className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
          onClick={() => navigate('/templates/create')}
        >
          + New Template
        </button>
      </div>

      {/* Table */}
      {templates.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          No templates yet. Create your first template.
        </div>
      ) : (
        <div className="rounded-lg border border-gray-200 overflow-hidden">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-700">Name</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">DA Type</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">Categories</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">Status</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">Created</th>
                <th className="px-4 py-3 text-right font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {templates.map(t => (
                <tr key={t.templateId} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-900">{t.name}</td>
                  <td className="px-4 py-3 text-gray-600">{t.daType}</td>
                  <td className="px-4 py-3 text-gray-600">{t.categoryCount}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                        t.status === 'Published'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {t.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-500">
                    {new Date(t.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      {t.status === 'Draft' && (
                        <button
                          className="text-sm text-blue-600 hover:underline"
                          onClick={() => navigate(`/templates/${t.templateId}/edit`)}
                        >
                          Edit
                        </button>
                      )}
                      <button
                        className={`text-sm hover:underline ${
                          t.status === 'Published' ? 'text-amber-600' : 'text-green-600'
                        }`}
                        onClick={() => handleTogglePublish(t)}
                        disabled={publishMutation.isPending || unpublishMutation.isPending}
                      >
                        {t.status === 'Published' ? 'Unpublish' : 'Publish'}
                      </button>
                      {t.status === 'Draft' && (
                        <button
                          className="text-sm text-red-500 hover:underline"
                          onClick={() => handleDelete(t)}
                          disabled={deleteMutation.isPending}
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

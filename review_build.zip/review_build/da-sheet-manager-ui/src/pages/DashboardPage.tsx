import { Layout, Users } from 'lucide-react'
import { clsx } from 'clsx'
import { useDashboardStats } from '../hooks/useDashboard'
import { useAuthStore } from '../store/authStore'

// ---- Stat card ----

interface StatCardProps {
  title: string
  value: number | undefined
  icon: React.ReactNode
  color: string
  loading: boolean
}

function StatCard({ title, value, icon, color, loading }: StatCardProps) {
  return (
    <div className="flex items-center gap-4 rounded-xl bg-white p-5 shadow-sm">
      <div className={clsx('flex h-12 w-12 items-center justify-center rounded-xl', color)}>
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium uppercase tracking-wide text-gray-500">{title}</p>
        {loading ? (
          <div className="mt-1 h-7 w-12 animate-pulse rounded bg-gray-200" />
        ) : (
          <p className="text-2xl font-bold text-gray-900">{value ?? '—'}</p>
        )}
      </div>
    </div>
  )
}

// ---- Page ----

export function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const isAdmin = user?.role === 'Admin'

  const { data: stats, isLoading: statsLoading } = useDashboardStats()

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-sm text-gray-500">
          Welcome back, <span className="font-medium">{user?.fullName}</span>.
        </p>
      </div>

      {/* Stat cards */}
      {isAdmin && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <StatCard
            title="Templates"
            value={stats?.templateCount}
            icon={<Layout className="h-6 w-6 text-purple-600" />}
            color="bg-purple-100"
            loading={statsLoading}
          />
          <StatCard
            title="Users"
            value={stats?.userCount}
            icon={<Users className="h-6 w-6 text-indigo-600" />}
            color="bg-indigo-100"
            loading={statsLoading}
          />
        </div>
      )}

      {!isAdmin && (
        <div className="rounded-xl bg-white p-8 text-center shadow-sm">
          <p className="text-gray-500">
            Use the sidebar to navigate to your assigned templates and resources.
          </p>
        </div>
      )}
    </div>
  )
}

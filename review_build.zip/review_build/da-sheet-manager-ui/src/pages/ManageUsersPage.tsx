import { useState, useMemo } from 'react'
import {
  UserPlus,
  Upload,
  Trash2,
  ToggleLeft,
  ToggleRight,
  KeyRound,
  CheckSquare,
  Square,
  AlertCircle,
  X,
  Loader2,
} from 'lucide-react'
import * as Dialog from '@radix-ui/react-dialog'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { clsx } from 'clsx'
import {
  useUsers,
  useCreateUser,
  useBulkCreateUsers,
  useBulkDeleteUsers,
  useToggleActive,
  useResetPassword,
} from '../hooks/useUsers'
import { useToast } from '../components/Toast'
import type { UserListItem, UserRole, UserCreateResult } from '../types/da-types'

// ============================================================
// Helpers
// ============================================================

function formatDate(iso: string) {
  return new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(
    new Date(iso),
  )
}

// ============================================================
// Add User Modal
// ============================================================

const addUserSchema = z.object({
  employeeCode: z.string().min(1, 'Employee code is required').max(20),
  fullName: z.string().min(1, 'Full name is required').max(200),
  email: z.string().email('Invalid email address').max(200),
  role: z.enum(['Admin', 'User'] as const),
  tempPassword: z
    .string()
    .min(8, 'At least 8 characters')
    .regex(/[A-Z]/, 'Needs uppercase')
    .regex(/[a-z]/, 'Needs lowercase')
    .regex(/\d/, 'Needs number')
    .regex(/[^A-Za-z0-9]/, 'Needs special char'),
})

type AddUserFormValues = z.infer<typeof addUserSchema>

interface AddUserModalProps {
  open: boolean
  onClose(): void
}

function AddUserModal({ open, onClose }: AddUserModalProps) {
  const { toast } = useToast()
  const createUser = useCreateUser()

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<AddUserFormValues>({
    resolver: zodResolver(addUserSchema),
    defaultValues: { role: 'User' },
  })

  async function onSubmit(values: AddUserFormValues) {
    try {
      await createUser.mutateAsync(values)
      toast({ title: 'User created', description: `${values.fullName} added successfully.`, variant: 'success' })
      reset()
      onClose()
    } catch (err) {
      toast({
        title: 'Failed to create user',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'error',
      })
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={(o) => !o && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/40" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-full max-w-md -translate-x-1/2 -translate-y-1/2 rounded-xl bg-white p-6 shadow-xl">
          <div className="mb-4 flex items-center justify-between">
            <Dialog.Title className="text-lg font-semibold text-gray-900">Add User</Dialog.Title>
            <Dialog.Close className="rounded p-1 text-gray-400 hover:bg-gray-100">
              <X className="h-4 w-4" />
            </Dialog.Close>
          </div>

          <form onSubmit={(e) => void handleSubmit(onSubmit)(e)} className="space-y-4" noValidate>
            <FormField label="Employee Code" error={errors.employeeCode?.message}>
              <input
                {...register('employeeCode')}
                className={inputCls(!!errors.employeeCode)}
                placeholder="EMP001"
              />
            </FormField>
            <FormField label="Full Name" error={errors.fullName?.message}>
              <input {...register('fullName')} className={inputCls(!!errors.fullName)} placeholder="Jane Doe" />
            </FormField>
            <FormField label="Email" error={errors.email?.message}>
              <input {...register('email')} type="email" className={inputCls(!!errors.email)} placeholder="jane@company.com" />
            </FormField>
            <FormField label="Role" error={errors.role?.message}>
              <select {...register('role')} className={inputCls(!!errors.role)}>
                <option value="User">User</option>
                <option value="Admin">Admin</option>
              </select>
            </FormField>
            <FormField label="Temporary Password" error={errors.tempPassword?.message}>
              <input
                {...register('tempPassword')}
                type="password"
                className={inputCls(!!errors.tempPassword)}
                placeholder="Min 8 chars, A–Z, a–z, 0–9, special"
                autoComplete="new-password"
              />
            </FormField>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={createUser.isPending}
                className="flex-1 rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
              >
                {createUser.isPending ? 'Creating…' : 'Create User'}
              </button>
            </div>
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}

// ============================================================
// Bulk Add Modal
// ============================================================

interface BulkAddModalProps {
  open: boolean
  onClose(): void
}

function BulkAddModal({ open, onClose }: BulkAddModalProps) {
  const { toast } = useToast()
  const bulkCreate = useBulkCreateUsers()
  const [csvText, setCsvText] = useState('')
  const [results, setResults] = useState<UserCreateResult[] | null>(null)
  const [parseError, setParseError] = useState<string | null>(null)

  function parseCsv(raw: string) {
    const lines = raw.trim().split('\n').filter((l) => l.trim())
    const parsed = []
    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split(',').map((p) => p.trim())
      if (parts.length < 5) {
        return { error: `Line ${i + 1}: expected 5 columns (EmployeeCode,FullName,Email,Role,TempPassword)` }
      }
      const [employeeCode, fullName, email, role, tempPassword] = parts
      if (!['Admin', 'User'].includes(role)) {
        return { error: `Line ${i + 1}: Role must be 'Admin' or 'User', got '${role}'` }
      }
      parsed.push({ employeeCode, fullName, email, role: role as UserRole, tempPassword })
    }
    return { users: parsed }
  }

  async function handleSubmit() {
    setParseError(null)
    const parsed = parseCsv(csvText)
    if ('error' in parsed) {
      setParseError(parsed.error ?? null)
      return
    }
    try {
      const result = await bulkCreate.mutateAsync({ users: parsed.users })
      setResults(result.results)
      const successCount = result.results.filter((r) => r.success).length
      toast({
        title: 'Bulk create complete',
        description: `${successCount}/${result.results.length} users created.`,
        variant: successCount === result.results.length ? 'success' : 'info',
      })
    } catch (err) {
      toast({
        title: 'Bulk create failed',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'error',
      })
    }
  }

  function handleClose() {
    setCsvText('')
    setResults(null)
    setParseError(null)
    onClose()
  }

  return (
    <Dialog.Root open={open} onOpenChange={(o) => !o && handleClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/40" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-full max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-xl bg-white p-6 shadow-xl">
          <div className="mb-4 flex items-center justify-between">
            <Dialog.Title className="text-lg font-semibold text-gray-900">Bulk Add Users</Dialog.Title>
            <Dialog.Close className="rounded p-1 text-gray-400 hover:bg-gray-100">
              <X className="h-4 w-4" />
            </Dialog.Close>
          </div>

          {!results ? (
            <>
              <p className="mb-3 text-sm text-gray-500">
                Paste one user per line:{' '}
                <code className="rounded bg-gray-100 px-1 text-xs">
                  EmployeeCode,FullName,Email,Role,TempPassword
                </code>
              </p>
              <textarea
                value={csvText}
                onChange={(e) => setCsvText(e.target.value)}
                rows={8}
                className="w-full rounded-md border border-gray-300 px-3 py-2 font-mono text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
                placeholder={`EMP002,John Smith,john@company.com,User,Pass@1234\nEMP003,Alice Admin,alice@company.com,Admin,Pass@5678`}
              />
              {parseError && (
                <div className="mt-2 flex items-start gap-2 rounded bg-red-50 px-3 py-2">
                  <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-red-500" />
                  <p className="text-xs text-red-700">{parseError}</p>
                </div>
              )}
              <div className="mt-4 flex gap-3">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => void handleSubmit()}
                  disabled={bulkCreate.isPending || !csvText.trim()}
                  className="flex-1 rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
                >
                  {bulkCreate.isPending ? (
                    <span className="flex items-center justify-center gap-1.5">
                      <Loader2 className="h-4 w-4 animate-spin" /> Importing…
                    </span>
                  ) : (
                    'Import Users'
                  )}
                </button>
              </div>
            </>
          ) : (
            <>
              <p className="mb-3 text-sm font-medium text-gray-700">Import Results</p>
              <div className="max-h-72 overflow-auto rounded-md border border-gray-200">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b bg-gray-50 text-left font-semibold text-gray-500">
                      <th className="px-3 py-2">Employee Code</th>
                      <th className="px-3 py-2">Status</th>
                      <th className="px-3 py-2">Error</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {results.map((r) => (
                      <tr key={r.employeeCode}>
                        <td className="px-3 py-2 font-mono">{r.employeeCode}</td>
                        <td className="px-3 py-2">
                          <span
                            className={clsx(
                              'inline-block rounded-full px-2 py-0.5 font-medium',
                              r.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700',
                            )}
                          >
                            {r.success ? 'Created' : 'Failed'}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-red-600">{r.error ?? '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="mt-4 w-full rounded-md bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200"
              >
                Close
              </button>
            </>
          )}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}

// ============================================================
// Bulk Delete Confirm Modal
// ============================================================

interface BulkDeleteModalProps {
  open: boolean
  count: number
  onConfirm(): void
  onClose(): void
  loading: boolean
}

function BulkDeleteModal({ open, count, onConfirm, onClose, loading }: BulkDeleteModalProps) {
  return (
    <Dialog.Root open={open} onOpenChange={(o) => !o && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/40" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-full max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-xl bg-white p-6 shadow-xl">
          <Dialog.Title className="mb-2 text-lg font-semibold text-gray-900">
            Confirm Delete
          </Dialog.Title>
          <p className="mb-6 text-sm text-gray-600">
            You are about to delete{' '}
            <span className="font-semibold text-red-600">{count} user{count !== 1 ? 's' : ''}</span>
            . This action cannot be undone.
          </p>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={onConfirm}
              disabled={loading}
              className="flex-1 rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60"
            >
              {loading ? 'Deleting…' : 'Delete'}
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}

// ============================================================
// Reset Password Modal
// ============================================================

const resetSchema = z.object({
  tempPassword: z
    .string()
    .min(8, 'At least 8 characters')
    .regex(/[A-Z]/, 'Needs uppercase')
    .regex(/[a-z]/, 'Needs lowercase')
    .regex(/\d/, 'Needs a number')
    .regex(/[^A-Za-z0-9]/, 'Needs a special character'),
})

type ResetFormValues = z.infer<typeof resetSchema>

interface ResetPasswordModalProps {
  open: boolean
  user: UserListItem | null
  onClose(): void
}

function ResetPasswordModal({ open, user, onClose }: ResetPasswordModalProps) {
  const { toast } = useToast()
  const resetPassword = useResetPassword()

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ResetFormValues>({ resolver: zodResolver(resetSchema) })

  async function onSubmit(values: ResetFormValues) {
    if (!user) return
    try {
      await resetPassword.mutateAsync({ id: user.userId, tempPassword: values.tempPassword })
      toast({ title: 'Password reset', description: `Temporary password set for ${user.fullName}.`, variant: 'success' })
      reset()
      onClose()
    } catch (err) {
      toast({
        title: 'Reset failed',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'error',
      })
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={(o) => !o && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/40" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-full max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-xl bg-white p-6 shadow-xl">
          <div className="mb-4 flex items-center justify-between">
            <Dialog.Title className="text-lg font-semibold text-gray-900">
              Reset Password
            </Dialog.Title>
            <Dialog.Close className="rounded p-1 text-gray-400 hover:bg-gray-100">
              <X className="h-4 w-4" />
            </Dialog.Close>
          </div>

          <p className="mb-4 text-sm text-gray-600">
            Set a new temporary password for{' '}
            <span className="font-semibold">{user?.fullName}</span>. They will be required to
            change it on next login.
          </p>

          <form onSubmit={(e) => void handleSubmit(onSubmit)(e)} className="space-y-4" noValidate>
            <FormField label="New Temporary Password" error={errors.tempPassword?.message}>
              <input
                {...register('tempPassword')}
                type="password"
                className={inputCls(!!errors.tempPassword)}
                autoComplete="new-password"
                placeholder="Min 8 chars with A–Z, a–z, 0–9, symbol"
              />
            </FormField>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={resetPassword.isPending}
                className="flex-1 rounded-md bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
              >
                {resetPassword.isPending ? 'Resetting…' : 'Reset'}
              </button>
            </div>
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}

// ============================================================
// Small shared helpers
// ============================================================

function inputCls(hasError: boolean) {
  return clsx(
    'w-full rounded-md border px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1',
    hasError
      ? 'border-red-400 focus:border-red-400 focus:ring-red-400'
      : 'border-gray-300 focus:border-brand-500 focus:ring-brand-500',
  )
}

function FormField({
  label,
  error,
  children,
}: {
  label: string
  error?: string
  children: React.ReactNode
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-gray-700">{label}</label>
      {children}
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  )
}

// ============================================================
// Main Page
// ============================================================

export function ManageUsersPage() {
  const { toast } = useToast()
  const { data: users, isLoading, isError } = useUsers()
  const toggleActive = useToggleActive()
  const bulkDelete = useBulkDeleteUsers()

  // Modal state
  const [showAddModal, setShowAddModal] = useState(false)
  const [showBulkAdd, setShowBulkAdd] = useState(false)
  const [showBulkDelete, setShowBulkDelete] = useState(false)
  const [resetUser, setResetUser] = useState<UserListItem | null>(null)

  // Selection state
  const [selected, setSelected] = useState<Set<number>>(new Set())

  const allIds = useMemo(() => users?.map((u) => u.userId) ?? [], [users])
  const allSelected = allIds.length > 0 && allIds.every((id) => selected.has(id))
  const someSelected = selected.size > 0

  function toggleSelectAll() {
    if (allSelected) {
      setSelected(new Set())
    } else {
      setSelected(new Set(allIds))
    }
  }

  function toggleOne(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  async function handleToggleActive(user: UserListItem) {
    try {
      await toggleActive.mutateAsync(user.userId)
      toast({
        title: user.isActive ? 'User deactivated' : 'User activated',
        description: `${user.fullName} is now ${user.isActive ? 'inactive' : 'active'}.`,
        variant: 'success',
      })
    } catch (err) {
      toast({
        title: 'Action failed',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'error',
      })
    }
  }

  async function handleBulkDelete() {
    try {
      const result = await bulkDelete.mutateAsync({ userIds: Array.from(selected) })
      setSelected(new Set())
      setShowBulkDelete(false)
      toast({
        title: 'Users deleted',
        description: `${result.deleted} deleted${result.failed.length > 0 ? `, ${result.failed.length} failed` : ''}.`,
        variant: result.failed.length > 0 ? 'info' : 'success',
      })
    } catch (err) {
      toast({
        title: 'Delete failed',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'error',
      })
    }
  }

  return (
    <div className="space-y-5">
      {/* Page header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Manage Users</h1>
          <p className="text-sm text-gray-500">Add, edit, and control user access.</p>
        </div>

        <div className="flex flex-wrap gap-2">
          {someSelected && (
            <button
              onClick={() => setShowBulkDelete(true)}
              className="flex items-center gap-1.5 rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm font-medium text-red-700 hover:bg-red-100"
            >
              <Trash2 className="h-4 w-4" />
              Delete ({selected.size})
            </button>
          )}
          <button
            onClick={() => setShowBulkAdd(true)}
            className="flex items-center gap-1.5 rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            <Upload className="h-4 w-4" />
            Bulk Add
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-md bg-brand-600 px-3 py-2 text-sm font-semibold text-white hover:bg-brand-700"
          >
            <UserPlus className="h-4 w-4" />
            Add User
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl bg-white shadow-sm">
        {isLoading ? (
          <div className="space-y-3 p-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-10 animate-pulse rounded bg-gray-100" />
            ))}
          </div>
        ) : isError ? (
          <div className="flex items-center gap-2 p-8 text-red-600">
            <AlertCircle className="h-5 w-5" />
            <p className="text-sm">Failed to load users. Please refresh the page.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">
                  <th className="px-4 py-3">
                    <button
                      onClick={toggleSelectAll}
                      className="text-gray-400 hover:text-gray-700"
                      aria-label="Select all"
                    >
                      {allSelected ? (
                        <CheckSquare className="h-4 w-4" />
                      ) : (
                        <Square className="h-4 w-4" />
                      )}
                    </button>
                  </th>
                  <th className="px-4 py-3">Employee Code</th>
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Must Change Pwd</th>
                  <th className="px-4 py-3">Created</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users && users.length > 0 ? (
                  users.map((user) => (
                    <tr
                      key={user.userId}
                      className={clsx(
                        'hover:bg-gray-50',
                        selected.has(user.userId) && 'bg-blue-50',
                      )}
                    >
                      {/* Checkbox */}
                      <td className="px-4 py-3">
                        <button
                          onClick={() => toggleOne(user.userId)}
                          className="text-gray-400 hover:text-brand-600"
                          aria-label={`Select ${user.fullName}`}
                        >
                          {selected.has(user.userId) ? (
                            <CheckSquare className="h-4 w-4 text-brand-600" />
                          ) : (
                            <Square className="h-4 w-4" />
                          )}
                        </button>
                      </td>

                      {/* Data columns */}
                      <td className="px-4 py-3 font-mono text-xs text-gray-700">
                        {user.employeeCode}
                      </td>
                      <td className="px-4 py-3 font-medium text-gray-900">{user.fullName}</td>
                      <td className="px-4 py-3 text-gray-600">{user.email}</td>
                      <td className="px-4 py-3">
                        <span
                          className={clsx(
                            'inline-block rounded-full px-2 py-0.5 text-xs font-medium',
                            user.role === 'Admin'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-gray-100 text-gray-700',
                          )}
                        >
                          {user.role}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={clsx(
                            'inline-block rounded-full px-2 py-0.5 text-xs font-medium',
                            user.isActive
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-700',
                          )}
                        >
                          {user.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        {user.mustChangePassword ? (
                          <span className="text-xs font-medium text-amber-600">Yes</span>
                        ) : (
                          <span className="text-xs text-gray-400">No</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-gray-500">{formatDate(user.createdAt)}</td>

                      {/* Actions */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => void handleToggleActive(user)}
                            disabled={toggleActive.isPending}
                            title={user.isActive ? 'Deactivate user' : 'Activate user'}
                            className={clsx(
                              'rounded p-1.5 text-sm',
                              user.isActive
                                ? 'text-green-600 hover:bg-green-50'
                                : 'text-gray-400 hover:bg-gray-100',
                            )}
                          >
                            {user.isActive ? (
                              <ToggleRight className="h-4 w-4" />
                            ) : (
                              <ToggleLeft className="h-4 w-4" />
                            )}
                          </button>
                          <button
                            onClick={() => setResetUser(user)}
                            title="Reset password"
                            className="rounded p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-600"
                          >
                            <KeyRound className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9} className="px-6 py-12 text-center text-gray-400">
                      No users found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <AddUserModal open={showAddModal} onClose={() => setShowAddModal(false)} />
      <BulkAddModal open={showBulkAdd} onClose={() => setShowBulkAdd(false)} />
      <BulkDeleteModal
        open={showBulkDelete}
        count={selected.size}
        onConfirm={() => void handleBulkDelete()}
        onClose={() => setShowBulkDelete(false)}
        loading={bulkDelete.isPending}
      />
      <ResetPasswordModal
        open={resetUser !== null}
        user={resetUser}
        onClose={() => setResetUser(null)}
      />
    </div>
  )
}

import { useQuery } from '@tanstack/react-query'
import { dashboardApi } from '../api/dashboard'

/** Fetch aggregate dashboard statistics */
export function useDashboardStats() {
  return useQuery({
    queryKey: ['dashboard', 'stats'],
    queryFn: () => dashboardApi.stats(),
    staleTime: 60 * 1000, // 1 minute
  })
}

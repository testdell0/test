import { useQuery } from '@tanstack/react-query'
import { authApi } from '../api/auth'
import { useAuthStore } from '../store/authStore'

/**
 * Fetches the current user from the server using the da_jwt cookie.
 * On success, syncs the result into the Zustand auth store.
 * On 401, the apiFetch client automatically clears the store and redirects to /login.
 */
export function useMe() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const setUser = useAuthStore((s) => s.setUser)

  return useQuery({
    queryKey: ['me'],
    queryFn: async () => {
      const user = await authApi.me()
      setUser(user)
      return user
    },
    // Only call /api/auth/me when we believe a session exists
    // (localStorage has isAuthenticated from a prior login).
    // On first visit there is no cookie, so skip to avoid a noisy 401.
    enabled: isAuthenticated,
    // Retry once on network hiccup but not on auth errors
    retry: (failureCount, error) => {
      if (error instanceof Error && 'status' in error) {
        const status = (error as { status: number }).status
        if (status === 401 || status === 403) return false
      }
      return failureCount < 1
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  })
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { templatesApi } from '../api/templates'
import type { CreateTemplateRequest, UpdateTemplateRequest } from '../types/da-types'

// ── Query Keys ─────────────────────────────────────────────────────────────

const tmplKeys = {
  all:    ['templates'] as const,
  detail: (id: number) => ['templates', id] as const,
}

// ── Queries ────────────────────────────────────────────────────────────────

/** Fetch all templates visible to the current user. */
export function useTemplates() {
  return useQuery({
    queryKey: tmplKeys.all,
    queryFn:  () => templatesApi.getAll(),
  })
}

/** Fetch a single template with full categories/params. */
export function useTemplate(id: number) {
  return useQuery({
    queryKey: tmplKeys.detail(id),
    queryFn:  () => templatesApi.getById(id),
    enabled:  id > 0,
  })
}

// ── Mutations ──────────────────────────────────────────────────────────────

export function useCreateTemplate() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: CreateTemplateRequest) => templatesApi.create(body),
    onSuccess: () => qc.invalidateQueries({ queryKey: tmplKeys.all }),
  })
}

export function useUpdateTemplate(id: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: UpdateTemplateRequest) => templatesApi.update(id, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: tmplKeys.all })
      qc.invalidateQueries({ queryKey: tmplKeys.detail(id) })
    },
  })
}

export function useDeleteTemplate() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => templatesApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: tmplKeys.all }),
  })
}

export function usePublishTemplate() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => templatesApi.publish(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: tmplKeys.all }),
  })
}

export function useUnpublishTemplate() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => templatesApi.unpublish(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: tmplKeys.all }),
  })
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { usersApi } from '../api/users'
import type {
  CreateUserRequest,
  BulkCreateUserRequest,
  BulkDeleteRequest,
} from '../types/da-types'

const USERS_KEY = ['users'] as const

/** Fetch all users (Admin only) */
export function useUsers() {
  return useQuery({
    queryKey: USERS_KEY,
    queryFn: () => usersApi.getAll(),
  })
}

/** Create a single new user */
export function useCreateUser() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (req: CreateUserRequest) => usersApi.create(req),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: USERS_KEY })
    },
  })
}

/** Bulk-create users from a parsed CSV list */
export function useBulkCreateUsers() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (req: BulkCreateUserRequest) => usersApi.bulkCreate(req),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: USERS_KEY })
    },
  })
}

/** Bulk-delete users by ID */
export function useBulkDeleteUsers() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (req: BulkDeleteRequest) => usersApi.bulkDelete(req),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: USERS_KEY })
    },
  })
}

/** Toggle a user's IS_ACTIVE flag */
export function useToggleActive() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => usersApi.toggleActive(id),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: USERS_KEY })
    },
  })
}

/** Admin reset of a user's temporary password */
export function useResetPassword() {
  return useMutation({
    mutationFn: ({ id, tempPassword }: { id: number; tempPassword: string }) =>
      usersApi.resetPassword(id, tempPassword),
  })
}

import { apiFetch } from './client'
import type {
  CaptchaResponse,
  LoginRequest,
  CurrentUser,
  ChangePasswordRequest,
} from '../types/da-types'

/** Shape returned by POST /api/auth/login */
export interface LoginApiResponse {
  user: CurrentUser
  passwordExpired: boolean
}

export const authApi = {
  /** GET /api/auth/captcha — returns a new math captcha challenge */
  getCaptcha(): Promise<CaptchaResponse> {
    return apiFetch<CaptchaResponse>('/api/auth/captcha')
  },

  /** POST /api/auth/login — authenticates user, sets da_jwt cookie */
  login(req: LoginRequest): Promise<LoginApiResponse> {
    return apiFetch<LoginApiResponse>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(req),
    })
  },

  /** POST /api/auth/logout — clears the da_jwt cookie server-side */
  logout(): Promise<void> {
    return apiFetch<void>('/api/auth/logout', { method: 'POST' })
  },

  /** GET /api/auth/me — returns the currently authenticated user's profile */
  me(): Promise<CurrentUser> {
    return apiFetch<CurrentUser>('/api/auth/me')
  },

  /** POST /api/auth/change-password — changes the authenticated user's password */
  changePassword(req: ChangePasswordRequest): Promise<void> {
    return apiFetch<void>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(req),
    })
  },
}

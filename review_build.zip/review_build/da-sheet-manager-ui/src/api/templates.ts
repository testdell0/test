import { apiFetch } from './client'
import type {
  TemplateListItem,
  TemplateDetail,
  CreateTemplateRequest,
  UpdateTemplateRequest,
} from '../types/da-types'

export const templatesApi = {
  // ── Queries ───────────────────────────────────────────────────────────────

  /** GET /api/templates — Returns all (admin) or Published only (user). */
  getAll: (): Promise<TemplateListItem[]> =>
    apiFetch('/api/templates'),

  /** GET /api/templates/{id} — Full detail with categories + params. */
  getById: (id: number): Promise<TemplateDetail> =>
    apiFetch(`/api/templates/${id}`),

  // ── Mutations ─────────────────────────────────────────────────────────────

  /** POST /api/templates — Create a new Draft template (Admin). */
  create: (body: CreateTemplateRequest): Promise<TemplateDetail> =>
    apiFetch('/api/templates', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  /** PUT /api/templates/{id} — Update template name/type/categories (Admin, Draft only). */
  update: (id: number, body: UpdateTemplateRequest): Promise<TemplateDetail> =>
    apiFetch(`/api/templates/${id}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  /** DELETE /api/templates/{id} — Delete Draft template (Admin). */
  delete: (id: number): Promise<void> =>
    apiFetch(`/api/templates/${id}`, { method: 'DELETE' }),

  /** POST /api/templates/{id}/publish — Publish template (Admin). */
  publish: (id: number): Promise<void> =>
    apiFetch(`/api/templates/${id}/publish`, { method: 'POST' }),

  /** POST /api/templates/{id}/unpublish — Revert to Draft (Admin). */
  unpublish: (id: number): Promise<void> =>
    apiFetch(`/api/templates/${id}/unpublish`, { method: 'POST' }),
}

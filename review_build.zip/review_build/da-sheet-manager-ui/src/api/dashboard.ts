import { apiFetch } from './client'
import type { DashboardStats } from '../types/da-types'

export const dashboardApi = {
  /** GET /api/dashboard/stats — aggregate counts for the dashboard */
  stats(): Promise<DashboardStats> {
    return apiFetch<DashboardStats>('/api/dashboard/stats')
  },
}

// Base fetch wrapper for all API calls.
// Reads VITE_API_BASE_URL from env or defaults to '' (same-origin via Vite proxy).
// Sends credentials: 'include' so the da_jwt HttpOnly cookie is attached on every request.
// On 401, clears the Zustand auth store and redirects to /login.

const BASE_URL = ((import.meta as any).env.VITE_API_BASE_URL as string | undefined) ?? ''

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly body?: unknown,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const url = `${BASE_URL}${path}`

  const response = await fetch(url, {
    ...init,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  })

  if (response.status === 401) {
    // Lazily import to avoid circular dep at module load time
    const { useAuthStore } = await import('../store/authStore')
    useAuthStore.getState().logout()

    // Only redirect if we're not already on the login page (prevents infinite loop)
    if (window.location.pathname !== '/login') {
      window.location.href = '/login'
      // Return a never-resolving promise so callers don't see a partial result
      return new Promise(() => undefined)
    }

    throw new ApiError(401, 'Not authenticated')
  }

  if (!response.ok) {
    let body: unknown
    try {
      body = await response.json()
    } catch {
      body = await response.text()
    }
    const message =
      typeof body === 'object' && body !== null && 'message' in body
        ? String((body as Record<string, unknown>)['message'])
        : `HTTP ${response.status}`
    throw new ApiError(response.status, message, body)
  }

  // 204 No Content — return undefined cast to T
  if (response.status === 204) {
    return undefined as unknown as T
  }

  return response.json() as Promise<T>
}

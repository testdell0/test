import { apiFetch } from './client'
import type {
  UserListItem,
  CreateUserRequest,
  BulkCreateUserRequest,
  BulkCreateResult,
  BulkDeleteRequest,
  BulkDeleteResult,
} from '../types/da-types'

export const usersApi = {
  /** GET /api/users — list all users (Admin only) */
  getAll(): Promise<UserListItem[]> {
    return apiFetch<UserListItem[]>('/api/users')
  },

  /** POST /api/users — create a single user (Admin only) */
  create(req: CreateUserRequest): Promise<UserListItem> {
    return apiFetch<UserListItem>('/api/users', {
      method: 'POST',
      body: JSON.stringify(req),
    })
  },

  /** POST /api/users/bulk — create multiple users from CSV/list (Admin only) */
  bulkCreate(req: BulkCreateUserRequest): Promise<BulkCreateResult> {
    return apiFetch<BulkCreateResult>('/api/users/bulk', {
      method: 'POST',
      body: JSON.stringify(req),
    })
  },

  /** DELETE /api/users/bulk — delete multiple users by ID (Admin only) */
  bulkDelete(req: BulkDeleteRequest): Promise<BulkDeleteResult> {
    return apiFetch<BulkDeleteResult>('/api/users/bulk', {
      method: 'DELETE',
      body: JSON.stringify(req),
    })
  },

  /** PATCH /api/users/:id/toggle-active — flip IS_ACTIVE for a user (Admin only) */
  toggleActive(id: number): Promise<void> {
    return apiFetch<void>(`/api/users/${id}/toggle-active`, { method: 'PATCH' })
  },

  /** POST /api/users/:id/reset-password — admin sets a new temporary password */
  resetPassword(id: number, tempPassword: string): Promise<void> {
    return apiFetch<void>(`/api/users/${id}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ tempPassword }),
    })
  },
}

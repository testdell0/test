// ============================================================
// Phase 1 Domain Types
// ============================================================

export type UserRole = 'Admin' | 'User'

// ------ Auth ------

export interface CurrentUser {
  userId: number
  employeeCode: string
  fullName: string
  email: string
  role: UserRole
  mustChangePassword: boolean
  passwordExpired?: boolean
}

export interface LoginRequest {
  /** Employee code OR email address */
  identifier: string
  password: string
  captchaToken: string
  captchaAnswer: string
}

export interface CaptchaResponse {
  /** Opaque server-side token identifying this captcha challenge */
  token: string
  /** Human-readable math question, e.g. "7 + 3 = ?" */
  question: string
}

export interface ChangePasswordRequest {
  currentPassword: string
  newPassword: string
  confirmNewPassword: string
}

// ------ Users ------

export interface UserListItem {
  userId: number
  employeeCode: string
  fullName: string
  email: string
  role: UserRole
  isActive: boolean
  mustChangePassword: boolean
  createdAt: string // ISO 8601
}

export interface CreateUserRequest {
  employeeCode: string
  fullName: string
  email: string
  role: UserRole
  tempPassword: string
}

export interface BulkCreateUserRequest {
  users: CreateUserRequest[]
}

export interface UserCreateResult {
  employeeCode: string
  success: boolean
  error?: string
}

export interface BulkCreateResult {
  results: UserCreateResult[]
}

export interface BulkDeleteRequest {
  userIds: number[]
}

export interface BulkDeleteResult {
  deleted: number
  failed: number[]
  error?: string
}

// ------ Dashboard ------

export interface DashboardStats {
  templateCount: number
  userCount: number
}

// ============================================================
// Phase 2 — Templates
// ============================================================

export interface TemplateListItem {
  templateId: number
  name: string
  daType: string
  status: 'Draft' | 'Published'
  categoryCount: number
  createdByName: string
  createdAt: string
  updatedAt: string
}

export interface TemplateParam {
  paramId: number
  name: string
  weightage: number
  sortOrder: number
}

export interface TemplateCategory {
  categoryId: number
  name: string
  sortOrder: number
  parameters: TemplateParam[]
  categoryWeightage: number
}

export interface TemplateDetail {
  templateId: number
  name: string
  daType: string
  description?: string
  status: 'Draft' | 'Published'
  createdByName: string
  createdAt: string
  updatedAt: string
  categories: TemplateCategory[]
}

export interface CreateParamRequest {
  name: string
  weightage: number
  sortOrder: number
}

export interface CreateCategoryRequest {
  name: string
  sortOrder: number
  parameters: CreateParamRequest[]
}

export interface CreateTemplateRequest {
  name: string
  daType: string
  description?: string
  categories: CreateCategoryRequest[]
}

export interface UpdateParamRequest extends CreateParamRequest {
  paramId?: number
}

export interface UpdateCategoryRequest {
  categoryId?: number
  name: string
  sortOrder: number
  parameters: UpdateParamRequest[]
}

export interface UpdateTemplateRequest {
  name: string
  daType: string
  description?: string
  categories: UpdateCategoryRequest[]
}

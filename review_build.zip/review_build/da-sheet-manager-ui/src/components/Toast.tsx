import * as ToastPrimitive from '@radix-ui/react-toast'
import { X } from 'lucide-react'
import { clsx } from 'clsx'
import React, { createContext, useContext, useState, useCallback } from 'react'

// ---- Types ----

export type ToastVariant = 'success' | 'error' | 'info'

interface ToastMessage {
  id: string
  title: string
  description?: string
  variant: ToastVariant
}

interface ToastContextValue {
  toast(opts: { title: string; description?: string; variant?: ToastVariant }): void
}

// ---- Context ----

const ToastContext = createContext<ToastContextValue | null>(null)

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast must be used inside <ToastProvider>')
  return ctx
}

// ---- Provider ----

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<ToastMessage[]>([])

  const toast = useCallback(
    ({
      title,
      description,
      variant = 'info',
    }: {
      title: string
      description?: string
      variant?: ToastVariant
    }) => {
      const id = Math.random().toString(36).slice(2)
      setMessages((prev) => [...prev, { id, title, description, variant }])
    },
    [],
  )

  function remove(id: string) {
    setMessages((prev) => prev.filter((m) => m.id !== id))
  }

  return (
    <ToastContext.Provider value={{ toast }}>
      <ToastPrimitive.Provider swipeDirection="right" duration={4000}>
        {children}

        {messages.map((msg) => (
          <ToastPrimitive.Root
            key={msg.id}
            onOpenChange={(open) => !open && remove(msg.id)}
            defaultOpen
            className={clsx(
              'pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-lg border px-4 py-3 shadow-lg',
              msg.variant === 'success' && 'border-green-200 bg-green-50',
              msg.variant === 'error' && 'border-red-200 bg-red-50',
              msg.variant === 'info' && 'border-blue-200 bg-blue-50',
            )}
          >
            <div className="flex-1">
              <ToastPrimitive.Title
                className={clsx(
                  'text-sm font-semibold',
                  msg.variant === 'success' && 'text-green-800',
                  msg.variant === 'error' && 'text-red-800',
                  msg.variant === 'info' && 'text-blue-800',
                )}
              >
                {msg.title}
              </ToastPrimitive.Title>
              {msg.description && (
                <ToastPrimitive.Description
                  className={clsx(
                    'mt-0.5 text-xs',
                    msg.variant === 'success' && 'text-green-700',
                    msg.variant === 'error' && 'text-red-700',
                    msg.variant === 'info' && 'text-blue-700',
                  )}
                >
                  {msg.description}
                </ToastPrimitive.Description>
              )}
            </div>
            <ToastPrimitive.Close
              className={clsx(
                'mt-0.5 rounded p-0.5',
                msg.variant === 'success' && 'text-green-600 hover:bg-green-100',
                msg.variant === 'error' && 'text-red-600 hover:bg-red-100',
                msg.variant === 'info' && 'text-blue-600 hover:bg-blue-100',
              )}
              aria-label="Dismiss"
            >
              <X className="h-3.5 w-3.5" />
            </ToastPrimitive.Close>
          </ToastPrimitive.Root>
        ))}

        <ToastPrimitive.Viewport className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 outline-none" />
      </ToastPrimitive.Provider>
    </ToastContext.Provider>
  )
}

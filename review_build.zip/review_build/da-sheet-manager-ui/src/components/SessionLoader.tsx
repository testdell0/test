import React from 'react'
import { useMe } from '../hooks/useAuth'

interface SessionLoaderProps {
  children: React.ReactNode
}

/**
 * Calls useMe() on mount to re-hydrate the auth store from the server.
 * Shows a full-screen spinner while the request is in flight.
 * Once the request resolves (success OR auth error — which triggers redirect),
 * renders children normally.
 */
export function SessionLoader({ children }: SessionLoaderProps) {
  const { isLoading } = useMe()

  if (isLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-4">
          <svg
            className="h-10 w-10 animate-spin text-brand-600"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            aria-label="Loading"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
            />
          </svg>
          <p className="text-sm text-gray-500">Loading session…</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { SessionLoader } from './components/SessionLoader'
import { ProtectedRoute } from './router/ProtectedRoute'
import { AppShell } from './components/AppShell'
import { ToastProvider } from './components/Toast'
import { LoginPage } from './pages/LoginPage'
import { ChangePasswordPage } from './pages/ChangePasswordPage'
import { DashboardPage } from './pages/DashboardPage'
import { ManageUsersPage } from './pages/ManageUsersPage'
import TemplatesPage from './pages/TemplatesPage'
import TemplatePage from './pages/TemplatePage'

// A single QueryClient instance for the whole app
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Don't refetch on window focus in dev to reduce noise
      refetchOnWindowFocus: import.meta.env.PROD,
      // Show stale data immediately while revalidating
      staleTime: 30_000,
    },
  },
})

// ---- App ----

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          <SessionLoader>
            <Routes>
              {/* Public */}
              <Route path="/login" element={<LoginPage />} />

              {/* Protected: change-password (standalone, no AppShell) */}
              <Route
                path="/change-password"
                element={
                  <ProtectedRoute>
                    <ChangePasswordPage />
                  </ProtectedRoute>
                }
              />

              {/* Protected: inside AppShell */}
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <AppShell />
                  </ProtectedRoute>
                }
              >
                <Route index element={<Navigate to="/dashboard" replace />} />

                <Route path="dashboard" element={<DashboardPage />} />

                {/* Phase 2 — Templates (admin only) */}
                <Route
                  path="templates"
                  element={
                    <ProtectedRoute adminOnly>
                      <TemplatesPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="templates/create"
                  element={
                    <ProtectedRoute adminOnly>
                      <TemplatePage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="templates/:id/edit"
                  element={
                    <ProtectedRoute adminOnly>
                      <TemplatePage />
                    </ProtectedRoute>
                  }
                />

                {/* Phase 1 — Users (admin only) */}
                <Route
                  path="users"
                  element={
                    <ProtectedRoute adminOnly>
                      <ManageUsersPage />
                    </ProtectedRoute>
                  }
                />
              </Route>

              {/* Fallback — redirect unknown paths to templates */}
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </SessionLoader>
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  )
}

using System.Linq.Expressions;

namespace DASheetManager.Data.Repositories;

/// <summary>
/// Generic repository contract providing basic CRUD and query operations
/// for any EF Core entity type.
/// </summary>
public interface IRepository<T> where T : class
{
    /// <summary>Returns all entities as an IQueryable (deferred execution).</summary>
    IQueryable<T> Query();

    /// <summary>Returns all entities as an IQueryable with no tracking (read-only).</summary>
    IQueryable<T> QueryNoTracking();

    /// <summary>Find a single entity by its primary key. Returns null if not found.</summary>
    Task<T?> GetByIdAsync(int id);

    /// <summary>Find a single entity matching the given predicate. Returns null if not found.</summary>
    Task<T?> FindAsync(Expression<Func<T, bool>> predicate);

    /// <summary>Return all entities matching the given predicate.</summary>
    Task<IEnumerable<T>> FindAllAsync(Expression<Func<T, bool>> predicate);

    /// <summary>Add a new entity to the context (not yet saved to DB).</summary>
    Task AddAsync(T entity);

    /// <summary>Add a collection of new entities to the context (not yet saved to DB).</summary>
    Task AddRangeAsync(IEnumerable<T> entities);

    /// <summary>Mark an entity as modified (not yet saved to DB).</summary>
    void Update(T entity);

    /// <summary>Mark an entity for deletion (not yet saved to DB).</summary>
    void Remove(T entity);

    /// <summary>Check if any entity satisfies the predicate.</summary>
    Task<bool> AnyAsync(Expression<Func<T, bool>> predicate);

    /// <summary>Count entities satisfying the predicate.</summary>
    Task<int> CountAsync(Expression<Func<T, bool>>? predicate = null);
}

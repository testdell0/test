using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;

namespace DASheetManager.Data.Repositories;

/// <summary>
/// Generic EF Core repository implementation.
/// All write operations are batched; call <see cref="IUnitOfWork.SaveChangesAsync"/> to persist.
/// </summary>
public class Repository<T> : IRepository<T> where T : class
{
    protected readonly DbContext _context;
    protected readonly DbSet<T> _dbSet;

    public Repository(DbContext context)
    {
        _context = context;
        _dbSet = context.Set<T>();
    }

    /// <inheritdoc/>
    public IQueryable<T> Query() => _dbSet.AsQueryable();

    /// <inheritdoc/>
    public IQueryable<T> QueryNoTracking() => _dbSet.AsNoTracking();

    /// <inheritdoc/>
    public async Task<T?> GetByIdAsync(int id) =>
        await _dbSet.FindAsync(id);

    /// <inheritdoc/>
    public async Task<T?> FindAsync(Expression<Func<T, bool>> predicate) =>
        await _dbSet.FirstOrDefaultAsync(predicate);

    /// <inheritdoc/>
    public async Task<IEnumerable<T>> FindAllAsync(Expression<Func<T, bool>> predicate) =>
        await _dbSet.Where(predicate).ToListAsync();

    /// <inheritdoc/>
    public async Task AddAsync(T entity) =>
        await _dbSet.AddAsync(entity);

    /// <inheritdoc/>
    public async Task AddRangeAsync(IEnumerable<T> entities) =>
        await _dbSet.AddRangeAsync(entities);

    /// <inheritdoc/>
    public void Update(T entity) =>
        _dbSet.Update(entity);

    /// <inheritdoc/>
    public void Remove(T entity) =>
        _dbSet.Remove(entity);

    /// <inheritdoc/>
    public async Task<bool> AnyAsync(Expression<Func<T, bool>> predicate) =>
        await _dbSet.AnyAsync(predicate);

    /// <inheritdoc/>
    public async Task<int> CountAsync(Expression<Func<T, bool>>? predicate = null) =>
        predicate is null
            ? await _dbSet.CountAsync()
            : await _dbSet.CountAsync(predicate);
}

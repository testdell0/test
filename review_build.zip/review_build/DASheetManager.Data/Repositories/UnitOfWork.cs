using DASheetManager.Data.Entities;

namespace DASheetManager.Data.Repositories;

public class UnitOfWork : IUnitOfWork
{
    private readonly OracleDbContext _context;

    public UnitOfWork(OracleDbContext context)
    {
        _context = context;
    }

    // ── Backing fields ─────────────────────────────────────────────────────

    private IRepository<DaUser>?                   _users;
    private IRepository<DaTemplate>?               _templates;
    private IRepository<DaTemplateCategory>?        _templateCategories;
    private IRepository<DaTemplateJudgmentParam>?   _templateJudgmentParams;

    // ── Properties ─────────────────────────────────────────────────────────

    public IRepository<DaUser>                    Users                  => _users                  ??= new Repository<DaUser>(_context);
    public IRepository<DaTemplate>                Templates              => _templates              ??= new Repository<DaTemplate>(_context);
    public IRepository<DaTemplateCategory>         TemplateCategories     => _templateCategories     ??= new Repository<DaTemplateCategory>(_context);
    public IRepository<DaTemplateJudgmentParam>    TemplateJudgmentParams => _templateJudgmentParams ??= new Repository<DaTemplateJudgmentParam>(_context);

    public async Task<int> SaveChangesAsync() => await _context.SaveChangesAsync();

    public void Dispose() => _context.Dispose();
}

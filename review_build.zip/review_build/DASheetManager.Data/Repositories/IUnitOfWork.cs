using DASheetManager.Data.Entities;

namespace DASheetManager.Data.Repositories;

public interface IUnitOfWork : IDisposable
{
    IRepository<DaUser>                    Users                  { get; }
    IRepository<DaTemplate>               Templates              { get; }
    IRepository<DaTemplateCategory>        TemplateCategories     { get; }
    IRepository<DaTemplateJudgmentParam>   TemplateJudgmentParams { get; }

    Task<int> SaveChangesAsync();
}

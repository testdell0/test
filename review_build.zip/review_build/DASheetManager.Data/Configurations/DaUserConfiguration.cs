using DASheetManager.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DASheetManager.Data.Configurations;

public class DaUserConfiguration : IEntityTypeConfiguration<DaUser>
{
    public void Configure(EntityTypeBuilder<DaUser> builder)
    {
        builder.ToTable("DA_USERS");

        builder.HasKey(u => u.UserId);

        builder.Property(u => u.UserId)
            .HasColumnName("USER_ID")
            .UseHiLo("SEQ_DA_USERS");

        builder.Property(u => u.EmployeeCode)
            .HasColumnName("EMPLOYEE_CODE")
            .HasMaxLength(50);

        builder.HasIndex(u => u.EmployeeCode)
            .IsUnique()
            .HasDatabaseName("UQ_DA_USERS_EMPLOYEE_CODE");

        builder.Property(u => u.FullName)
            .HasColumnName("FULL_NAME")
            .HasMaxLength(200);

        builder.Property(u => u.Email)
            .HasColumnName("EMAIL")
            .HasMaxLength(255);

        builder.HasIndex(u => u.Email)
            .IsUnique()
            .HasDatabaseName("UQ_DA_USERS_EMAIL");

        builder.Property(u => u.Role)
            .HasColumnName("ROLE")
            .HasMaxLength(20)
            .HasDefaultValue("User");

        builder.Property(u => u.PasswordHash)
            .HasColumnName("PASSWORD_HASH")
            .HasMaxLength(500)
            .IsRequired(false);

        builder.Property(u => u.MustChangePassword)
            .HasColumnName("MUST_CHANGE_PASSWORD")
            .HasDefaultValue(true);

        builder.Property(u => u.PasswordChangedAt)
            .HasColumnName("PASSWORD_CHANGED_AT")
            .IsRequired(false);

        builder.Property(u => u.IsActive)
            .HasColumnName("IS_ACTIVE")
            .HasDefaultValue(true);

        builder.Property(u => u.CreatedAt)
            .HasColumnName("CREATED_AT");

        builder.Property(u => u.UpdatedAt)
            .HasColumnName("UPDATED_AT");
    }
}

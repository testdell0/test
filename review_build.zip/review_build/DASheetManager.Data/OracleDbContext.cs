using DASheetManager.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace DASheetManager.Data;

public class OracleDbContext : DbContext
{
    public OracleDbContext(DbContextOptions<OracleDbContext> options) : base(options) { }

    public DbSet<DaUser>                   Users                  => Set<DaUser>();
    public DbSet<DaTemplate>               Templates              => Set<DaTemplate>();
    public DbSet<DaTemplateCategory>       TemplateCategories     => Set<DaTemplateCategory>();
    public DbSet<DaTemplateJudgmentParam>  TemplateJudgmentParams => Set<DaTemplateJudgmentParam>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OracleDbContext).Assembly);
    }
}

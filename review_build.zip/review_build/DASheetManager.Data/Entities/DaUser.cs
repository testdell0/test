namespace DASheetManager.Data.Entities;

public class DaUser
{
    public int UserId { get; set; }

    /// <summary>Unique employee code used as an alternate login identifier.</summary>
    public string EmployeeCode { get; set; } = string.Empty;

    public string FullName { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    /// <summary>"Admin" or "User"</summary>
    public string Role { get; set; } = "User";

    /// <summary>BCrypt hash. Nullable to support future SSO-only users who have no local password.</summary>
    public string? PasswordHash { get; set; }

    /// <summary>
    /// True when the user must change their password before doing anything else.
    /// Defaulted to true on creation so admins who reset passwords force the user to pick a new one.
    /// </summary>
    public bool MustChangePassword { get; set; } = true;

    /// <summary>
    /// UTC timestamp of the last successful password change.
    /// Null means the password has never been changed (treated as expired).
    /// Used for the 90-day auto-expiry policy.
    /// </summary>
    public DateTime? PasswordChangedAt { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    // Navigation properties
    public ICollection<DaTemplate> CreatedTemplates { get; set; } = new List<DaTemplate>();
}

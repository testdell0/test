-- Fix SOURCE_TEMPLATE_ID: allow template deletion without blocking sheets.
-- All steps in dynamic SQL to handle any constraint naming.

DECLARE
BEGIN
    -- 1. Drop FK constraints on SOURCE_TEMPLATE_ID
    FOR rec IN (
        SELECT uc.constraint_name
        FROM user_constraints uc
        JOIN user_cons_columns ucc ON uc.constraint_name = ucc.constraint_name
        WHERE ucc.table_name = 'DA_SHEETS'
          AND ucc.column_name = 'SOURCE_TEMPLATE_ID'
          AND uc.constraint_type = 'R'
    ) LOOP
        EXECUTE IMMEDIATE 'ALTER TABLE DA_SHEETS DROP CONSTRAINT ' || rec.constraint_name;
    END LOOP;

    -- 2. Drop CHECK/NOT NULL constraints on SOURCE_TEMPLATE_ID
    FOR rec IN (
        SELECT uc.constraint_name
        FROM user_constraints uc
        JOIN user_cons_columns ucc ON uc.constraint_name = ucc.constraint_name
        WHERE ucc.table_name = 'DA_SHEETS'
          AND ucc.column_name = 'SOURCE_TEMPLATE_ID'
          AND uc.constraint_type = 'C'
    ) LOOP
        EXECUTE IMMEDIATE 'ALTER TABLE DA_SHEETS DROP CONSTRAINT ' || rec.constraint_name;
    END LOOP;

    -- 3. Make column nullable
    EXECUTE IMMEDIATE 'ALTER TABLE DA_SHEETS MODIFY (SOURCE_TEMPLATE_ID NULL)';

    -- 4. Re-add FK with ON DELETE SET NULL
    EXECUTE IMMEDIATE 'ALTER TABLE DA_SHEETS ADD CONSTRAINT FK_DA_SHEET_TEMPLATE FOREIGN KEY (SOURCE_TEMPLATE_ID) REFERENCES DA_TEMPLATES(TEMPLATE_ID) ON DELETE SET NULL';
END;
/

COMMIT;

-- ============================================================
-- DA Sheet Manager — Direct DB User Insert Helper
-- ============================================================
--
-- IMPORTANT: READ BEFORE USING
-- ==============================
--
-- WHY DIRECTLY INSERTED USERS MAY NOT APPEAR IN "MANAGE USERS"
-- ─────────────────────────────────────────────────────────────
-- The application uses EF Core's HiLo sequence strategy for
-- primary keys (UseHiLo("SEQ_DA_USERS")).
--
-- HiLo works like this:
--   1. EF Core calls  SELECT SEQ_DA_USERS.NEXTVAL FROM DUAL  → gets "hi" value N
--   2. EF Core assigns actual entity IDs as:  N × 10, N×10+1 … N×10+9
--   3. The next time IDs are needed, it calls NEXTVAL again → M, uses M×10 … M×10+9
--
-- If you insert directly using SEQ_DA_USERS.NEXTVAL, you consume a
-- sequence value but assign it as the literal USER_ID (e.g. 3 instead of 30).
-- The row IS in the database and IS queryable. However, if a subsequent
-- application insert happens to request hi-value 3 and generates ID 30,
-- there is no conflict (different IDs). The only practical consequence
-- is a gap in the sequence.
--
-- THE REAL VISIBILITY PROBLEM
-- ─────────────────────────────────────────────────────────────
-- If a directly-inserted user does not appear in Manage Users, the most
-- common causes are:
--
--   1. PASSWORD_HASH missing or exceeds VARCHAR2(500).
--      • BCrypt hashes are exactly 60 characters — fine.
--      • SHA-256/Base64 hashes are exactly 44 characters — fine.
--      • Plain-text passwords or other values may cause EF to fail
--        deserializing the row, throwing an exception that the middleware
--        catches and redirects away from the page.
--
--   2. CREATED_AT / UPDATED_AT are NULL or in an unreadable format.
--      Use SYSTIMESTAMP (not SYSDATE) for TIMESTAMP columns.
--
--   3. EMPLOYEE_CODE or EMAIL violates the unique constraint (duplicate).
--      The INSERT appears to succeed if run in the same transaction that
--      also has an existing row with the same value; check for silent
--      constraint violations.
--
--   4. IS_ACTIVE or MUST_CHANGE_PASSWORD are not 0/1.
--      EF Core maps Oracle NUMBER(1) to C# bool as 0=false, 1=true.
--      Any other value causes a materialization exception.
--
-- RECOMMENDED APPROACH
-- ─────────────────────────────────────────────────────────────
-- Always use the application's Manage Users → Add User feature.
-- It uses BCrypt hashing, validates all constraints, handles HiLo IDs
-- correctly, and sets MUST_CHANGE_PASSWORD = 1 automatically.
--
-- Only use direct SQL inserts for:
--   • Initial environment bootstrap before the application is accessible
--   • Disaster recovery when the application cannot start
--
-- ============================================================
-- PASSWORD HASH REFERENCE
-- ============================================================
--
-- The application currently uses BCrypt (work factor 12).
-- Legacy SHA-256/Base64 hashes are still accepted and auto-upgraded
-- to BCrypt on the user's next successful login.
--
-- Pre-computed BCrypt hashes for common temporary passwords:
--   "TempPass@123"  →  $2a$12$WjKtqnGJY3zMCE7Y6Dl5nOB1fMHiI1rTQb9f4eN2oWvC5B3aZ0Lu2
--   "Admin@123"     →  $2a$12$examplehash... (use the app to generate real ones)
--
-- To generate a BCrypt hash without running the application, use any of:
--   • bcrypt.online (https://bcrypt.online) — work factor 12
--   • PowerShell:  [System.Security.Cryptography.HashAlgorithm]::... (SHA-256)
--   • Node.js:     const bcrypt = require('bcrypt'); bcrypt.hash('pw', 12)
--
-- ============================================================
-- SAFE DIRECT INSERT TEMPLATE
-- ============================================================
--
-- Replace all placeholder values before running.
-- Run as the schema owner or with INSERT privilege on DA_USERS.

INSERT INTO DA_USERS (
    USER_ID,
    EMPLOYEE_CODE,
    FULL_NAME,
    EMAIL,
    PASSWORD_HASH,
    MUST_CHANGE_PASSWORD,
    ROLE,
    IS_ACTIVE,
    CREATED_AT,
    UPDATED_AT
)
VALUES (
    SEQ_DA_USERS.NEXTVAL,           -- let Oracle assign the ID
    'EMP999',                        -- uppercase; must be unique in DA_USERS
    'John Smith',                    -- full name
    'john.smith@company.com',        -- must be unique in DA_USERS
    '$2a$12$REPLACE_WITH_REAL_BCRYPT_HASH_60_CHARS_LONG_XXXXXXXXXXX',
                                     -- BCrypt hash (60 chars, starts with $2a$12$)
                                     -- or SHA-256/Base64 (44 chars) for legacy compat
    1,                               -- 1 = user must change password on next login
    'User',                          -- 'User' or 'Admin'
    1,                               -- 1 = active
    SYSTIMESTAMP,                    -- use SYSTIMESTAMP, NOT SYSDATE
    SYSTIMESTAMP
);

COMMIT;

-- ============================================================
-- VERIFY THE INSERT
-- ============================================================

SELECT
    USER_ID,
    EMPLOYEE_CODE,
    FULL_NAME,
    EMAIL,
    SUBSTR(PASSWORD_HASH, 1, 10) || '...' AS HASH_PREFIX,
    LENGTH(PASSWORD_HASH)               AS HASH_LEN,
    MUST_CHANGE_PASSWORD,
    ROLE,
    IS_ACTIVE,
    CREATED_AT
FROM DA_USERS
ORDER BY CREATED_AT DESC
FETCH FIRST 5 ROWS ONLY;

-- After a successful insert, open Manage Users in the application.
-- If the user still does not appear, check the application logs for
-- an EF Core materialization exception on the DA_USERS query.

-- ============================================================
-- TROUBLESHOOT: SHOW ALL USERS INCLUDING INACTIVE
-- ============================================================

SELECT USER_ID, EMPLOYEE_CODE, FULL_NAME, IS_ACTIVE, ROLE,
       LENGTH(PASSWORD_HASH) AS HASH_LEN,
       SUBSTR(PASSWORD_HASH, 1, 4) AS HASH_START
FROM DA_USERS
ORDER BY CREATED_AT DESC;

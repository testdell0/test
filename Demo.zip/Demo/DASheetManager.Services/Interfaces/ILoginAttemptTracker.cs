namespace DASheetManager.Services.Interfaces;

/// <summary>
/// Tracks failed login attempts per employee code and enforces a temporary lockout
/// after too many consecutive failures.
/// Registered as a Singleton so the state survives across requests.
/// </summary>
public interface ILoginAttemptTracker
{
    /// <summary>Returns true if the account is currently locked out.</summary>
    bool IsLockedOut(string employeeCode);

    /// <summary>
    /// Returns a human-readable description of the remaining lockout duration,
    /// or null if not locked out.
    /// </summary>
    string? GetLockoutMessage(string employeeCode);

    /// <summary>Record a failed login attempt. May trigger a lockout.</summary>
    void RecordFailure(string employeeCode);

    /// <summary>Clear the failure counter after a successful login.</summary>
    void RecordSuccess(string employeeCode);
}

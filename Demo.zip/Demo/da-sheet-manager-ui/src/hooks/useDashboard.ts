import { useQuery } from '@tanstack/react-query'
import { dashboardApi } from '@/api/dashboard'

export function useDashboardStats() {
  return useQuery({
    queryKey: ['dashboard', 'stats'],
    queryFn: () => dashboardApi.stats(),
    staleTime: 60 * 1000, // 1 min
  })
}

export function useRecentSheets() {
  return useQuery({
    queryKey: ['dashboard', 'recent-sheets'],
    queryFn: () => dashboardApi.recentSheets(),
    staleTime: 60 * 1000,
  })
}
